
import os
import sys
from datetime import datetime, timezone

# Asegurar que el path del backend esté disponible
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.supabase_client import get_supabase, get_risk_config
from app.core.logger import log_info, log_warning

def cleanup_excess():
    sb = get_supabase()
    risk_config = get_risk_config()
    limit = int(risk_config.get('max_positions_per_symbol', 4))
    
    print(f"--- INICIANDO LIMPIEZA DE EXCESOS (Límite: {limit} por símbolo) ---")

    # 1. FOREX POSITIONS
    print("\n[FOREX] Verificando excesos...")
    res_forex = sb.table('forex_positions').select('*').eq('status', 'open').order('opened_at', desc=False).execute()
    forex_pos = res_forex.data or []
    
    forex_counts = {}
    for p in forex_pos:
        sym = p['symbol']
        forex_counts[sym] = forex_counts.get(sym, 0) + 1
        
        if forex_counts[sym] > limit:
            print(f"  -> CERRANDO EXCESO FOREX: {sym} (ID: {p['id']}) - Abierta el {p['opened_at']}")
            sb.table('forex_positions').update({
                'status': 'closed',
                'close_reason': 'excess_cleanup',
                'closed_at': datetime.now(timezone.utc).isoformat()
            }).eq('id', p['id']).execute()
    
    # 2. CRYPTO POSITIONS
    print("\n[CRYPTO] Verificando excesos...")
    res_crypto = sb.table('positions').select('*').eq('status', 'open').order('opened_at', desc=False).execute()
    crypto_pos = res_crypto.data or []
    
    crypto_counts = {}
    for p in crypto_pos:
        sym = p['symbol']
        crypto_counts[sym] = crypto_counts.get(sym, 0) + 1
        
        if crypto_counts[sym] > limit:
            print(f"  -> CERRANDO EXCESO CRYPTO: {sym} (ID: {p['id']}) - Abierta el {p['opened_at']}")
            sb.table('positions').update({
                'status': 'closed',
                'close_reason': 'excess_cleanup',
                'closed_at': datetime.now(timezone.utc).isoformat()
            }).eq('id', p['id']).execute()

    print("\n--- LIMPIEZA FINALIZADA ---")

if __name__ == "__main__":
    cleanup_excess()
