"""
eTrader — Config Package
"""
