import logging
from datetime import datetime, timedelta
from app.execution.binance_connector import get_client, get_account_balance
from app.workers.alerts_service import send_kill_switch_alert

def activar_kill_switch(supabase, reason: str):
    try:
        # 1. Obtener el ID dinámicamente o usar el que tenemos en cache
        config = supabase.table('risk_config').select('id').limit(1).execute()
        if not config.data:
            logging.error("No risk_config found to activate kill switch")
            return
            
        config_id = config.data[0]['id']

        # 2. Actualizar risk_config
        supabase.table('risk_config').update({
            'bot_active': False
        }).eq('id', config_id).execute()
        
        # 3. Insertar en alert_events
        supabase.table('alert_events').insert({
            'event_type': 'kill_switch',
            'severity': 'critical',
            'message': f'KILL SWITCH ACTIVADO: {reason}',
            'telegram_sent': False, 
            'email_sent': False
        }).execute()
        
        # 4. Intentar cerrar todas las posiciones abiertas
        from app.execution.order_manager import close_all_positions
        client = get_client()
        close_all_positions(supabase, client)
        
        # 5. Enviar alerta
        send_kill_switch_alert(reason)
        
        logging.critical(f"KILL SWITCH TRIGGERED: {reason}")
    except Exception as e:
        logging.error(f"Error activating kill switch: {e}")

def check_daily_loss_at_cycle_start(risk_config: dict, supabase):
    try:
        today_start = datetime.utcnow().replace(
            hour=0, minute=0, second=0, microsecond=0
        ).isoformat()

        daily_pnl = supabase.table('positions') \
            .select('realized_pnl') \
            .eq('status', 'closed') \
            .gte('closed_at', today_start) \
            .execute()

        total_daily_loss = sum(
            float(p['realized_pnl']) 
            for p in daily_pnl.data 
            if float(p['realized_pnl']) < 0
        )

        client = get_client()
        balance = get_account_balance(client, 'USDT')
        max_daily_loss_pct = float(risk_config.get('max_daily_loss_pct', 5.0))
        max_daily_loss_usdt = balance * (max_daily_loss_pct / 100)

        if abs(total_daily_loss) >= max_daily_loss_usdt:
            activar_kill_switch(supabase, f'Daily loss limit reached: ${abs(total_daily_loss):.2f}')
            return False
            
        return True
    except Exception as e:
        logging.error(f"Error checking daily loss: {e}")
        return True

def validate_signal(
    signal: dict,
    oco_params: dict,
    risk_config: dict,
    supabase_client
) -> dict:
    # CHECK 0 — Bloqueos de Seguridad por Subprocesos
    from app.core.safety_manager import is_crypto_safety_blocked, check_db_safety_block, get_rule_expected_direction
    if is_crypto_safety_blocked() or check_db_safety_block('crypto_futures'):
        return { 'approved': False, 'reason': 'SAFETY_BLOCK_CRYPTO_ACTIVE' }

    # CHECK 0.1 — Coherencia de Regla vs Dirección
    rule_code = signal.get('rule_code')
    direction = signal.get('direction') or signal.get('signal_type')
    if not direction and oco_params:
        direction = 'long' if 'BUY' in str(oco_params.get('side', '')).upper() else 'short'
    
    if direction and rule_code:
        expected = get_rule_expected_direction(rule_code)
        if expected and expected != direction.strip().lower():
            return { 'approved': False, 'reason': f'INCOHERENT_RULE_DIRECTION ({rule_code} expected {expected}, got {direction})' }

    # CHECK 1 — Bot activo:
    if not risk_config.get('bot_active', True):
        return { 'approved': False, 'reason': 'BOT_INACTIVE' }

    # CHECK 2 — El bot debe estar activo (ya se checa arriba, pero para robustez):
    if not risk_config.get('bot_active', True):
        return { 'approved': False, 'reason': 'KILL_SWITCH_ACTIVE' }

    # CHECK 3 — No exceder trades abiertos simultáneos (GLOBAL):
    try:
        open_positions_res = supabase_client.table('positions') \
            .select('symbol', count='exact') \
            .eq('status', 'open') \
            .execute()
        
        max_open = int(risk_config.get('max_open_trades', 15))
        current_open = open_positions_res.count or 0

        if current_open >= max_open:
            return { 'approved': False, 'reason': f'MAX_OPEN_TRADES_REACHED ({current_open}/{max_open})' }
    except Exception as e:
        logging.error(f"Error checking global open trades: {e}")
        current_open = 999 # FAIL-CLOSED

    # CHECK 4 — No exceder posiciones por símbolo:
    try:
        from app.core.crypto_symbols import crypto_symbol_match_variants
        variants = crypto_symbol_match_variants(signal['symbol'])
        symbol_positions = supabase_client.table('positions') \
            .select('id', count='exact') \
            .in_('symbol', variants) \
            .eq('status', 'open') \
            .execute()
            
        max_per_symbol = int(risk_config.get('max_positions_per_symbol', 4))
        current_symbol_open = symbol_positions.count if symbol_positions.count is not None else 999

        if current_symbol_open >= max_per_symbol:
            return { 'approved': False, 'reason': f'MAX_POSITIONS_PER_SYMBOL_REACHED ({signal["symbol"]}: {current_symbol_open}/{max_per_symbol})' }
            
    except Exception as e:
        logging.error(f"Error checking per-symbol positions: {e}")

    # CHECK 5 — Pérdida diaria no superada (ya se checa al inicio del ciclo, pero re-validamos por si acaso):
    # (Ya está en check_daily_loss_at_cycle_start)
    
    # CHECK 6 — Verificar pérdida horaria (kill switch proactivo):
    try:
        one_hour_ago = (datetime.utcnow() - timedelta(hours=1)).isoformat()
        hourly_pnl = supabase_client.table('positions') \
            .select('realized_pnl') \
            .eq('status', 'closed') \
            .gte('closed_at', one_hour_ago) \
            .execute()

        total_hourly_loss = sum(
            float(p['realized_pnl'])
            for p in hourly_pnl.data
            if float(p['realized_pnl']) < 0
        )

        client = get_client()
        balance = get_account_balance(client, 'USDT')
        
        # Fallback to capital_operativo if balance is zero or fetch failed
        if not balance or balance <= 0:
            try:
                config_res = supabase_client.table('trading_config').select('capital_operativo').eq('id', 1).maybe_single().execute()
                balance = float(config_res.data.get('capital_operativo', 500))
            except:
                balance = 500

        kill_switch_pct = float(risk_config.get('kill_switch_loss_pct', 3.0))
        kill_switch_usdt = balance * (kill_switch_pct / 100)

        if total_hourly_loss < 0 and abs(total_hourly_loss) >= kill_switch_usdt:
            activar_kill_switch(supabase_client, f'Hourly kill switch triggered: ${abs(total_hourly_loss):.2f}')
            return { 'approved': False, 'reason': 'KILL_SWITCH_HOURLY_TRIGGERED' }
    except Exception as e:
        logging.error(f"Error checking hourly loss: {e}")

    return {
        'approved': True,
        'reason': 'ALL_CHECKS_PASSED',
        'balance_usdt': locals().get('balance', 0),
        'daily_loss_usdt': 0, 
        'open_positions': current_open
    }
