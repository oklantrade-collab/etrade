"""
Forex Worker Standalone (Protobuf v3.1)

# FIXES:
# 1. Re-conexion automatica (Auto-reconnect) si cTrader desconecta.
# 2. Divisor Universal de 100,000 estable.
# 3. Limpieza de datos corruptos integrada.
# 4. Carga explicita del .env del backend (evita conflicto con .env padre).
"""

import os
import sys
import traceback
import json
import time
import threading

#     PASO 1: Resolver rutas y cargar .env manualmente    
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, "..", ".."))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

# Carga manual del .env (robusta)
dotenv_path = os.path.join(root_dir, '.env')
discovered_keys = []
if os.path.exists(dotenv_path):
    # Intentamos leer el archivo completo primero para ver qu  hay
    try:
        with open(dotenv_path, 'rb') as f:
            raw = f.read()
            # Detectar si es UTF-16 (comun en Windows si se guardo con Notepad)
            content = ""
            if raw.startswith(b'\xff\xfe') or raw.startswith(b'\xfe\xff'):
                content = raw.decode('utf-16')
            else:
                content = raw.decode('utf-8', errors='ignore')
            
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, _, value = line.partition('=')
                key = key.strip()
                value = value.strip()
                if value and value[0] in ('"', "'") and value[-1] == value[0]:
                    value = value[1:-1]
                os.environ[key] = value
                discovered_keys.append(key)
    except Exception as e:
        print(f"[ERROR] Fallo critico leyendo .env: {e}")

    s_url = os.getenv('SUPABASE_URL', '')
    print(f"[INFO] .env procesado. Total llaves: {len(discovered_keys)}")
    print(f"[INFO] Llaves encontradas: {', '.join(discovered_keys[:5])}...")
    print(f"[INFO] SUPABASE_URL detectada: {'S ' if s_url else 'NO'} ({len(s_url)} chars)")
    
    if not s_url:
        print(f"[CRITICAL]  SUPABASE_URL no encontrada en {dotenv_path}!")
        print(f"[DEBUG] Primeros 100 caracteres del archivo: {repr(content[:100])}")
else:
    print(f"[ERROR] No se encontro .env en {dotenv_path}")
    sys.exit(1)

#     PASO 2: Imports que dependen del .env    
import numpy as np
import pandas as pd
from datetime import datetime, timezone
from app.core.safety_manager import register_heartbeat, check_circuit_breaker

from twisted.internet import reactor, threads, task
from ctrader_open_api import Client, Protobuf, TcpProtocol, EndPoints
from ctrader_open_api.messages.OpenApiMessages_pb2 import *
from ctrader_open_api.messages.OpenApiModelMessages_pb2 import *
from supabase import create_client
from dataclasses import field
from app.strategy.proactive_exit import evaluate_proactive_exit
from app.strategy.dynamic_sl_manager import evaluate_sl_action
from app.strategy.capital_protection import ProtectionState, evaluate_volatile_trailing_v2, evaluate_trailing_stop

#     PASO 3: Config    
CLIENT_ID     = os.getenv('CTRADER_CLIENT_ID')
CLIENT_SECRET = os.getenv('CTRADER_CLIENT_SECRET')
ACCOUNT_ID    = int(os.getenv('CTRADER_ACCOUNT_ID', 0))
ACCESS_TOKEN  = os.getenv('CTRADER_ACCESS_TOKEN')
CTRADER_ENV   = os.getenv('CTRADER_ENV', 'live')

SUPABASE_URL  = os.getenv('SUPABASE_URL')
SUPABASE_KEY  = os.getenv('SUPABASE_SERVICE_KEY')

# DEFAULT fallback symbols
DEFAULT_FOREX_SYMBOLS = ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD']

TF_MAP = {
    '5m':  ProtoOATrendbarPeriod.M5,
    '15m': ProtoOATrendbarPeriod.M15,
    '1h':  ProtoOATrendbarPeriod.H1,
    '4h':  ProtoOATrendbarPeriod.H4,
    '1d':  ProtoOATrendbarPeriod.D1,
}

# Divisores de precio por simbolo
SYMBOL_DIVISORS = {
    'EURUSD': 100000,
    'GBPUSD': 100000,
    'USDJPY': 100000,
    'USDCHF': 100000,
    'AUDUSD': 100000,
    'NZDUSD': 100000,
    'USDCAD': 100000,
    'EURGBP': 100000,
    'EURJPY': 100000,
    'GBPJPY': 100000,
    'XAUUSD': 100000,
    'XAGUSD': 100000,
    'US30':   100,
    'US500':  100,
    'NAS100': 100,
}

def get_divisor(symbol):
    return SYMBOL_DIVISORS.get(symbol, 100000)


STATE = { 'symbol_ids': {}, 'prices': {}, 'candles': {}, 'cycle_count': 0, 'highest_prices_cache': {}, 'lowest_prices_cache': {} }
sb = create_client(SUPABASE_URL, SUPABASE_KEY)

def calculate_parabolic_sar(df, start=0.02, increment=0.02, maximum=0.20):
    """Calculo interno de SAR Parabolic para evitar dependencias de 'app'"""
    n = len(df)
    sar, trend, ep, af = np.zeros(n), np.zeros(n, dtype=int), np.zeros(n), np.zeros(n)
    sar[0], trend[0], ep[0], af[0] = df['c'].iloc[0], 0, df['c'].iloc[0], start
    for i in range(1, n):
        p_trend, p_sar, p_ep, p_af = trend[i-1], sar[i-1], ep[i-1], af[i-1]
        hi, lo, hp1, lp1 = df['h'].iloc[i], df['l'].iloc[i], df['h'].iloc[i-1], df['l'].iloc[i-1]
        hp2, lp2 = (df['h'].iloc[i-2] if i>=2 else hp1), (df['l'].iloc[i-2] if i>=2 else lp1)
        if p_trend == 0:
            if hi >= hp1 or lo >= lp1: trend[i], sar[i], ep[i] = 1, lp1, hp1
            else: trend[i], sar[i], ep[i] = -1, hp1, lp1
            af[i] = start
            continue
        nxt_sar, c_af, c_ep = p_sar, p_af, p_ep
        if p_trend > 0:
            if hp1 > c_ep: c_ep, c_af = hp1, min(maximum, c_af + increment)
            nxt_sar = min(min(lp1, lp2), p_sar + c_af * (c_ep - p_sar))
            if nxt_sar > lo: trend[i], sar[i], ep[i], af[i] = -1, c_ep, lo, start
            else: trend[i], sar[i], ep[i], af[i] = 1, nxt_sar, c_ep, c_af
        else:
            if lp1 < c_ep: c_ep, c_af = lp1, min(maximum, c_af + increment)
            nxt_sar = max(max(hp1, hp2), p_sar + c_af * (c_ep - p_sar))
            if nxt_sar < hi: trend[i], sar[i], ep[i], af[i] = 1, c_ep, hi, start
            else: trend[i], sar[i], ep[i], af[i] = -1, nxt_sar, c_ep, c_af
    df['sar'], df['sar_trend'] = sar, trend
    return df

class StandaloneForexWorker:
    def __init__(self):
        env = CTRADER_ENV
        self.host = EndPoints.PROTOBUF_LIVE_HOST if env == 'live' else EndPoints.PROTOBUF_DEMO_HOST
        self.port = EndPoints.PROTOBUF_PORT
        self.client = Client(host=self.host, port=self.port, protocol=TcpProtocol)
        self.client.setConnectedCallback(self.on_connected)
        self.client.setDisconnectedCallback(self.on_disconnected)
        self.client.setMessageReceivedCallback(self.on_message)
        self.execution = None  # Se inicializa despues de auth
        self.symbols = DEFAULT_FOREX_SYMBOLS

    def safe_send(self, req):
        from twisted.internet import reactor
        def _send():
            try:
                d = self.client.send(req)
                if hasattr(d, 'addErrback'):
                    d.addErrback(lambda f: None) # Silence timeout errors
            except Exception as e:
                self.log(f"Error sending request: {e}", "ERROR")
        
        reactor.callFromThread(_send)

    def log(self, msg, level='INFO'):
        from app.core.logger import log_info, log_error, log_warning
        
        ts = datetime.now().strftime('%H:%M:%S')
        
        # Clean message for console (ASCII only to avoid 'charmap' errors on Windows)
        # Use errors='replace' to turn non-ASCII into '?'
        console_msg = str(msg).encode('ascii', errors='replace').decode('ascii')
        
        # Clean message for DB (UTF-8 is fine for Supabase)
        db_msg = str(msg).encode('utf-8', errors='replace').decode('utf-8')
        
        # Console output
        print(f"[{ts}] [{level}] {console_msg}")
        sys.stdout.flush()
        
        # DB output
        try:
            if level == 'ERROR' or level == 'CRITICAL':
                log_error('forex_worker', db_msg)
            elif level == 'WARNING':
                log_warning('forex_worker', db_msg)
            else:
                log_info('forex_worker', db_msg)
        except Exception as e:
            # Fallback if DB logging fails
            print(f"[{ts}] [ERROR] Failed to log to DB: {e}")

    def start(self):
        from app.core.safety_manager import set_current_worker
        set_current_worker('forex_worker')
        self.log(f"Iniciando Worker v3.1 (Rutas Windows OK)...")
        self._load_dynamic_symbols()
        self.client.startService()
        # Iniciar ciclos base
        task.LoopingCall(self.send_heartbeat).start(25, now=False)
        task.LoopingCall(self.run_cycle).start(60, now=False)
        reactor.run()

    def on_connected(self, client):
        self.log("Conectado a cTrader. Autenticando...")
        self.send_app_auth()

    def on_disconnected(self, client, reason):
        self.log(f"Desconectado de cTrader ({reason}). Reintentando en 10s...", "WARNING")
        time.sleep(10)
        try: self.client.startService()
        except: pass

    def send_heartbeat(self):
        """Mantener viva la conexion (Requerido cada 25s)"""
        try:
            from ctrader_open_api.messages.OpenApiCommonMessages_pb2 import ProtoHeartbeatEvent
            req = ProtoHeartbeatEvent()
            self.safe_send(req)
        except Exception as e:
            self.log(f"Error enviando heartbeat: {e}", "ERROR")

    def _load_dynamic_symbols(self):
        """Carga la lista de simbolos desde trading_config -> regime_params."""
        try:
            res = sb.table('trading_config').select('regime_params').eq('id', 1).execute()
            data = res.data[0] if res.data else {}
            if data.get('regime_params'):
                assets = data['regime_params'].get('forex_assets')
                if assets and isinstance(assets, list):
                    self.symbols = assets
                    self.log(f"Configuracion dinamica cargada: {', '.join(self.symbols)}")
                else:
                    self.log("No se encontro 'forex_assets' in regime_params. Usando valores por defecto.")
            else:
                self.log("No se pudo cargar trading_config. Usando valores por defecto.")
        except Exception as e:
            self.log(f"Error cargando s mbolos din micos: {e}. Usando valores por defecto.")

    def _init_execution_service(self):
        """Inicializa el Execution Service despues de cargar simbolos."""
        try:
            from app.workers.forex_execution_service import ForexExecutionService
            self.execution = ForexExecutionService(
                worker=self, 
                supabase_client=sb,
                state_ref=STATE,
                symbols_ref=self.symbols
            )
            self.log("[OK] Execution Service iniciado")

            # Ciclo de evaluacion de estrategias (cada 5 min, con offset de 30s)
            reactor.callLater(30, self._start_evaluation_loop)

            # Ciclo de gestion de posiciones (cada 15s) - OPTIMIZADO PARA MEMORIA
            self._mgmt_task = task.LoopingCall(self.execution.run_position_management)
            self._mgmt_task.start(15, now=False)

        except Exception as e:
            self.log(f"Error iniciando Execution Service: {e}", "ERROR")
            self.log(traceback.format_exc(), "ERROR")

    def _start_evaluation_loop(self):
        """Inicia el loop de evaluacion de estrategias."""
        self._eval_task = task.LoopingCall(self.execution.run_evaluation_cycle)
        self._eval_task.start(300, now=True)  # Cada 5 min, ejecutar inmediatamente

    def on_message(self, client, message):
        pt = message.payloadType
        if pt == ProtoOAApplicationAuthRes().payloadType: 
            self.log("Autenticacion de Aplicacion OK. Autenticando cuenta...")
            self.send_acc_auth()
        elif pt == ProtoOAAccountAuthRes().payloadType: 
            self.log("Autenticacion de Cuenta OK. Cargando simbolos...")
            self.load_symbols()
        elif pt == ProtoOAErrorRes().payloadType:
            err = Protobuf.extract(message)
            self.log(f"ERROR DE CTRADER: {err.errorCode} - {err.description}", "ERROR")
        elif pt == ProtoOASymbolsListRes().payloadType:
            res = Protobuf.extract(message)
            count = 0
            for sym in res.symbol:
                base_name = sym.symbolName.split('.')[0].upper().strip()
                if base_name in self.symbols: 
                    STATE['symbol_ids'][base_name] = sym.symbolId
                    count += 1
            if count > 0:
                self.log(f"Simbolos vinculados: {count} ({', '.join(STATE['symbol_ids'].keys())})")
            self.subscribe_spots(); self.warmup_all()
            # Iniciar Execution Service despues de cargar simbolos
            reactor.callLater(5, self._init_execution_service)
        elif pt == ProtoOASpotEvent().payloadType:
            self.handle_spot(Protobuf.extract(message))
        elif pt == ProtoOAGetTrendbarsRes().payloadType:
            self.handle_bars(Protobuf.extract(message))
        elif pt == ProtoOAExecutionEvent().payloadType:
            self._handle_execution_event(Protobuf.extract(message))

    def _handle_execution_event(self, event):
        """Maneja respuestas de ejecucion de ordenes de cTrader."""
        try:
            if hasattr(event, 'order') and event.order:
                order = event.order
                self.log(
                    f"  Orden cTrader: id={order.orderId} "
                    f"status={event.executionType} "
                    f"symbol_id={order.tradeData.symbolId if hasattr(order, 'tradeData') else 'N/A'}"
                )
            
            if hasattr(event, 'position') and event.position:
                pos = event.position
                pid = pos.positionId
                p_status = pos.positionStatus
                self.log(f"  Posicion cTrader: id={pid} status={p_status}")

                # Vincular ID de cTrader con la DB si es una nueva posicion abierta
                if p_status == 1: # 1 = OPEN
                    # Buscar el simbolo por ID
                    name = next((n for n, sid in STATE['symbol_ids'].items() if sid == pos.tradeData.symbolId), None)
                    if name:
                        side = 'long' if pos.tradeData.tradeSide == 1 else 'short'
                        # Buscar la posicion mas reciente abierta en la DB que no tenga ID vinculado
                        try:
                            res = sb.table('forex_positions')\
                                .select('id')\
                                .eq('symbol', name)\
                                .eq('side', side)\
                                .eq('status', 'open')\
                                .is_('ctrader_pos_id', 'null')\
                                .order('opened_at', desc=True)\
                                .limit(1).execute()
                            
                            if res.data:
                                db_id = res.data[0]['id']
                                sb.table('forex_positions').update({'ctrader_pos_id': pid}).eq('id', db_id).execute()
                                self.log(f"[SYNC] Vinculado cTrader ID {pid} a posicion DB {db_id}")
                        except Exception as e:
                            self.log(f"Error vinculando ID: {e}", "ERROR")

        except Exception as e:
            self.log(f"Error procesando evento de ejecucion: {e}", "ERROR")

    def close_position(self, pos_id, volume_units):
        """Envía orden de cierre a cTrader."""
        try:
            from ctrader_open_api.messages.OpenApiMessages_pb2 import ProtoOAClosePositionReq
            req = ProtoOAClosePositionReq()
            req.ctidTraderAccountId = ACCOUNT_ID
            req.positionId = int(pos_id)
            req.volume = int(volume_units)
            self.safe_send(req)
            self.log(f"[CTRIDER] Enviada solicitud de cierre para posicion {pos_id}")
            return True
        except Exception as e:
            self.log(f"Error enviando cierre a cTrader: {e}", "ERROR")
            return False

    def trigger_forex_reentry_standalone(self, symbol, side, lots, df_15m):
        try:
            if df_15m is None or len(df_15m) < 20:
                return
                
            df = df_15m.copy()
            df['ema9'] = df['close'].ewm(span=9, adjust=False).mean()
            df['ema20'] = df['close'].ewm(span=20, adjust=False).mean()
            
            last_row = df.iloc[-1]
            ema9 = float(last_row['ema9'])
            ema20 = float(last_row['ema20'])
            
            mode_val = 'paper'
            
            orders = [
                {'limit_price': ema9, 'pct': 40, 'name': 'Order 1 (EMA9)'},
                {'limit_price': ema20, 'pct': 60, 'name': 'Order 2 (EMA20)'}
            ]
            
            from datetime import datetime, timezone, timedelta
            for op in orders:
                limit_px = round(op['limit_price'], 5)
                qty_val = round(lots * (op['pct'] / 100.0), 2)
                
                if qty_val <= 0:
                    continue
                    
                new_order = {
                    'symbol': symbol,
                    'direction': side.lower(),
                    'order_type': 'limit',
                    'trade_type': 'swing_ema',
                    'rule_code': 'AaApexEma' if side.lower() in ('long', 'buy') else 'BbApexEma',
                    'limit_price': limit_px,
                    'sl_price': 0,
                    'tp1_price': 0,
                    'tp2_price': 0,
                    'band_name': op['name'],
                    'status': 'pending',
                    'mode': mode_val,
                    'expires_at': (datetime.now(timezone.utc) + timedelta(hours=4)).isoformat(),
                    'sizing_pct': op['pct'] / 100.0,
                    'timeframe': '15m',
                    'movement_type': 'trend_ema',
                    'signal_quality': 'high',
                    'fib_zone_entry': 0
                }
                
                sb.table('pending_orders').insert(new_order).execute()
                self.log(f"🎯 [FOREX TS STANDALONE RE-ENTRY LIMIT] {symbol} {side.upper()}: {op['name']} colocada a {limit_px} | Lots: {qty_val}")
                
                # Telegram notification
                try:
                    from app.workers.alerts_service import send_telegram_message
                    from twisted.internet import reactor
                    reactor.callInThread(lambda: asyncio.run(send_telegram_message(
                        f"🎯 RE-ENTRADA TRAILING STOP STANDALONE FOREX [{symbol}]\n"
                        f"Dirección: {side.upper()}\n"
                        f"Nivel: {op['name']}\n"
                        f"Precio LIMIT: {limit_px:.5f}\n"
                        f"Lots: {qty_val}\n"
                        f"Modo: {mode_val.upper()}"
                    )))
                except Exception as tg_e:
                    self.log(f"Telegram alert error: {tg_e}")
        except Exception as e:
            self.log(f"Error placing forex reentry: {e}", "ERROR")

    def amend_position(self, pos_id, sl_price=None, tp_price=None, symbol=None):
        """Modifica SL/TP en cTrader."""
        try:
            from ctrader_open_api.messages.OpenApiMessages_pb2 import ProtoOAAmendPositionSLTPReq
            req = ProtoOAAmendPositionSLTPReq()
            req.ctidTraderAccountId = ACCOUNT_ID
            req.positionId = int(pos_id)
            
            divisor = get_divisor(symbol) if symbol else 100000
            
            if sl_price:
                req.stopLoss = int(round(sl_price * divisor))
            if tp_price:
                req.takeProfit = int(round(tp_price * divisor))
            
            self.safe_send(req)
            self.log(f"[CTRIDER] Enviada modificacion SL={sl_price}/TP={tp_price} para {pos_id}")
            return True
        except Exception as e:
            self.log(f"Error enviando modificacion a cTrader: {e}", "ERROR")
            return False

    def send_app_auth(self):
        req = ProtoOAApplicationAuthReq(); req.clientId = CLIENT_ID; req.clientSecret = CLIENT_SECRET; self.safe_send(req)
    def send_acc_auth(self):
        req = ProtoOAAccountAuthReq(); req.ctidTraderAccountId = ACCOUNT_ID; req.accessToken = ACCESS_TOKEN; self.safe_send(req)
    def load_symbols(self):
        req = ProtoOASymbolsListReq(); req.ctidTraderAccountId = ACCOUNT_ID; self.safe_send(req)

    def subscribe_spots(self):
        req = ProtoOASubscribeSpotsReq(); req.ctidTraderAccountId = ACCOUNT_ID
        for sid in STATE['symbol_ids'].values(): req.symbolId.append(sid)
        self.safe_send(req)

    def warmup_all(self):
        """Carga historica inicial no bloqueante para evitar congelar el reactor."""
        self.log("Preparando datos historicos (Lazy Warmup)...")
        # Marcamos que estamos en fase de arranque para NO guardar historial pesado en DB
        STATE['is_warming_up'] = True
        
        delay = 0.5
        for sym in self.symbols:
            self.log(f"-> Programando carga de {sym}...")
            # 5m (NUEVO para Trailing SHORT)
            reactor.callLater(delay, self.request_bars, sym, '5m', 200)
            delay += 1.5
            # 15m
            reactor.callLater(delay, self.request_bars, sym, '15m', 300)
            delay += 2.0
            # 1h
            reactor.callLater(delay, self.request_bars, sym, '1h', 100)
            delay += 1.5
            # 4h
            reactor.callLater(delay, self.request_bars, sym, '4h', 100)
            delay += 1.5
            # 1d
            reactor.callLater(delay, self.request_bars, sym, '1d', 100)
            delay += 2.0
            
        # Desactivar warmup tras un tiempo prudencial (ej. 30 segundos)
        reactor.callLater(delay + 5.0, self._finish_warmup)

    def _finish_warmup(self):
        self.log("Warmup inicial completado en memoria. El guardado en DB se activara en el siguiente ciclo.")
        STATE['is_warming_up'] = False

    def request_bars(self, symbol, tf, limit=500):
        sid = STATE['symbol_ids'].get(symbol); p = TF_MAP.get(tf)
        if not sid or not p: return
        now_ms = int(time.time() * 1000)
        # Factor de minutos por TF
        tf_mins = {'15m': 15, '1h': 60, '4h': 240, '1d': 1440}
        m = tf_mins.get(tf, 15)
        from_ms = now_ms - (m * limit * 60 * 1000)
        req = ProtoOAGetTrendbarsReq(); req.ctidTraderAccountId = ACCOUNT_ID; req.symbolId = sid; req.period = p
        req.fromTimestamp = from_ms; req.toTimestamp = now_ms; req.count = limit; self.safe_send(req)

    def handle_spot(self, spot):
        name = next((n for n, sid in STATE['symbol_ids'].items() if sid == spot.symbolId), None)
        if not name: return
        div = get_divisor(name)
        bid_raw = spot.bid or 0
        ask_raw = spot.ask or 0

        # FIX: Preserve previous values for partial spot updates
        # cTrader sometimes sends only bid OR only ask, not both
        prev = STATE['prices'].get(name, {})
        bid = bid_raw / div if bid_raw else prev.get('bid', 0)
        ask = ask_raw / div if ask_raw else prev.get('ask', 0)

        if bid and ask:
            mid = (bid + ask) / 2
        elif bid:
            mid = bid
        elif ask:
            mid = ask
        else:
            mid = prev.get('mid', 0)

        if bid and ask:
            mid = (bid + ask) / 2
            if name == 'XAUUSD':
                self.log(f"DEBUG XAUUSD SPOT VERIFIED_V4: raw_bid={bid_raw}, raw_ask={ask_raw}, div={div}, bid={bid}, ask={ask}, mid={mid}")
            STATE['prices'][name] = {'bid': bid, 'ask': ask, 'mid': mid}

    def handle_bars(self, res):
        name = next((n for n, sid in STATE['symbol_ids'].items() if sid == res.symbolId), None)
        if not name: return
        
        # Robustly extract period value (handles raw int, enum wrapper, or string)
        period_val = res.period
        if hasattr(period_val, 'value'):
            period_val = period_val.value
        try:
            period_int = int(period_val)
        except (ValueError, TypeError):
            period_int = period_val
            
        p_rev = {}
        for k, v in TF_MAP.items():
            val = v
            if hasattr(val, 'value'):
                val = val.value
            try:
                p_rev[int(val)] = k
            except (ValueError, TypeError):
                p_rev[val] = k
                
        tf = p_rev.get(period_int, '15m')
        div = get_divisor(name)
        bars = []
        for b in res.trendbar:
            low = b.low / div
            if name == 'XAUUSD':
                self.log(f"DEBUG XAUUSD BAR: raw_low={b.low}, div={div}, low={low}")
            bars.append({'ts': b.utcTimestampInMinutes*60, 'o': low+b.deltaOpen/div, 'h': low+b.deltaHigh/div, 'l': low, 'c': low+b.deltaClose/div, 'v': b.volume or 0})
        if bars:
            self.log(f"Recibidas {len(bars)} velas de {name} ({tf})", "DEBUG")
            STATE['candles'][f"{name}_{tf}"] = bars
            threads.deferToThread(self.process_and_save, name, tf, bars)

    def safe_db_execute(self, query, retries=3):
        """Ejecuta una consulta a Supabase con reintentos para manejar inestabilidad de red."""
        for i in range(retries):
            try:
                return query.execute()
            except Exception as e:
                err_str = str(e)
                # Si es un error de Gateway o Schema Cache, esperamos m s tiempo
                wait_time = 5 * (i + 1)
                if "502" in err_str or "503" in err_str or "504" in err_str or "PGRST002" in err_str:
                    wait_time = 10 * (i + 1)
                
                self.log(f"Reintentando DB ({i+1}/{retries}) en {wait_time}s por error: {e}", "WARNING")
                if i < retries - 1:
                    time.sleep(wait_time)
                else:
                    raise e
        return None

    def process_and_save(self, sym, tf, bars):
        try:
            from app.analysis.indicators_v2 import calculate_all_indicators
            df_raw = pd.DataFrame(bars)
            # Renombrar para compatibilidad con indicators_v2
            df_raw = df_raw.rename(columns={'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close', 'v': 'volume'})
            
            # Calcular todos los indicadores (MACD 4C, Pinescript, Bandas, SAR)
            df = calculate_all_indicators(df_raw, {})
            
            # NUEVO: Lazy Warmup. Si estamos arrancando, no guardamos el historial pesado en DB
            # pero SÍ sincronizamos MEMORY_STORE para que las señales funcionen desde el inicio
            if STATE.get('is_warming_up', False) and len(df) > 10:
                self._sync_memory_store(sym, tf, df)
                return

            rows = []
            for i, row in df.tail(300).iterrows():
                rows.append({
                    'symbol': sym, 
                    'exchange': 'icmarkets', 
                    'timeframe': tf,
                    'open_time': datetime.fromtimestamp(row['ts'], timezone.utc).isoformat(),
                    'open':   float(row['open']), 
                    'high':   float(row['high']), 
                    'low':    float(row['low']), 
                    'close':  float(row['close']),
                    'volume': int(row['volume']), 
                    'basis':  float(row['basis']),
                    'sar':    float(row['sar']), 
                    'sar_trend': int(row['sar_trend']),
                    'upper_1': float(row.get('upper_1', 0)), 
                    'upper_2': float(row.get('upper_2', 0)),
                    'upper_3': float(row.get('upper_3', 0)),
                    'upper_4': float(row.get('upper_4', 0)),
                    'upper_5': float(row.get('upper_5', 0)),
                    'upper_6': float(row.get('upper_6', 0)),
                    'lower_1': float(row.get('lower_1', 0)), 
                    'lower_2': float(row.get('lower_2', 0)),
                    'lower_3': float(row.get('lower_3', 0)),
                    'lower_4': float(row.get('lower_4', 0)),
                    'lower_5': float(row.get('lower_5', 0)),
                    'lower_6': float(row.get('lower_6', 0)),
                    'pinescript_signal': str(row.get('pinescript_signal', '')) if row.get('pinescript_signal') in ('Buy', 'Sell') else None,
                    'is_closed': True
                })
            if rows: 
                self.safe_db_execute(sb.table('market_candles').upsert(rows, on_conflict='symbol,exchange,timeframe,open_time'))
            
            # CRITICAL FIX: Sincronizar MEMORY_STORE para que forex_execution_service pueda leer datos
            self._sync_memory_store(sym, tf, df)
        except Exception as e: 
            self.log(f"Error procesando {sym} ({tf}):\n{traceback.format_exc()}", "ERROR")

    def _sync_memory_store(self, symbol, tf, df):
        """
        Sincroniza el DataFrame procesado con MEMORY_STORE para que
        forex_execution_service.py pueda acceder a los indicadores necesarios
        (SIPV patterns, EMAs, ADX, DI+/DI-, ema20_angle/phase).
        
        SIN ESTE MÉTODO, MEMORY_STORE está vacío para forex y NUNCA se generan señales.
        """
        try:
            from app.core.memory_store import update_memory_df
            
            if df is None or df.empty or len(df) < 20:
                return
            
            df_mem = df.copy()
            
            # --- EMAs compatibles con el formato esperado (ema1=3, ema2=9, ema3=20, ema4=50, ema5=200) ---
            if 'close' in df_mem.columns:
                close_col = df_mem['close']
            elif 'c' in df_mem.columns:
                close_col = df_mem['c']
            else:
                return
            
            df_mem['ema1'] = close_col.ewm(span=3, adjust=False).mean()   # EMA 3
            df_mem['ema2'] = close_col.ewm(span=9, adjust=False).mean()   # EMA 9
            df_mem['ema3'] = close_col.ewm(span=20, adjust=False).mean()  # EMA 20
            df_mem['ema4'] = close_col.ewm(span=50, adjust=False).mean()  # EMA 50
            df_mem['ema5'] = close_col.ewm(span=200, adjust=False).mean() # EMA 200
            
            # --- ADX, DI+, DI- ---
            high_col = df_mem.get('high', df_mem.get('h'))
            low_col = df_mem.get('low', df_mem.get('l'))
            if high_col is not None and low_col is not None:
                tr = np.maximum(high_col - low_col, 
                       np.maximum(abs(high_col - close_col.shift(1)), 
                                  abs(low_col - close_col.shift(1))))
                df_mem['atr'] = tr.rolling(window=14).mean()
                
                dm_plus = np.where(
                    (high_col - high_col.shift(1)) > (low_col.shift(1) - low_col),
                    np.maximum(high_col - high_col.shift(1), 0), 0)
                dm_minus = np.where(
                    (low_col.shift(1) - low_col) > (high_col - high_col.shift(1)),
                    np.maximum(low_col.shift(1) - low_col, 0), 0)
                
                tr_14 = tr.rolling(window=14).mean()
                df_mem['plus_di'] = 100 * (pd.Series(dm_plus, index=df_mem.index).rolling(14).mean() / (tr_14 + 1e-10))
                df_mem['minus_di'] = 100 * (pd.Series(dm_minus, index=df_mem.index).rolling(14).mean() / (tr_14 + 1e-10))
                dx = 100 * abs(df_mem['plus_di'] - df_mem['minus_di']) / (df_mem['plus_di'] + df_mem['minus_di'] + 1e-10)
                df_mem['adx'] = dx.rolling(window=14).mean()
            
            # --- EMA20 Angle y Phase ---
            ema20 = df_mem['ema3']  # ema3 = EMA 20
            if len(ema20) >= 3:
                df_mem['ema20_angle'] = ema20.diff()
                df_mem['ema20_phase'] = np.where(
                    df_mem['ema20_angle'] > 0, 'rising',
                    np.where(df_mem['ema20_angle'] < 0, 'falling', 'flat'))
            
            # --- SIPV Candlestick Patterns ---
            o = df_mem.get('open', df_mem.get('o'))
            h = high_col
            l = low_col
            c = close_col
            
            if o is not None and h is not None and l is not None:
                body = abs(c - o)
                full_range = h - l + 1e-10
                
                # Dragonfly Doji (bullish): Larga sombra inferior, sin sombra superior
                lower_shadow = np.minimum(o, c) - l
                upper_shadow = h - np.maximum(o, c)
                df_mem['is_dragonfly'] = (lower_shadow > body * 2) & (upper_shadow < body * 0.5) & (body < full_range * 0.3)
                
                # Gravestone Doji (bearish): Larga sombra superior, sin sombra inferior
                df_mem['is_gravestone'] = (upper_shadow > body * 2) & (lower_shadow < body * 0.5) & (body < full_range * 0.3)
                
                # Doji: Body muy pequeño
                df_mem['is_doji'] = body < full_range * 0.1
                
                # Bullish Engulfing
                prev_o = o.shift(1)
                prev_c = c.shift(1)
                df_mem['is_bullish_engulfing'] = (prev_c < prev_o) & (c > o) & (c > prev_o) & (o < prev_c)
                
                # Bearish Engulfing
                df_mem['is_bearish_engulfing'] = (prev_c > prev_o) & (c < o) & (c < prev_o) & (o > prev_c)
                
                # Low higher than previous low
                df_mem['low_higher_than_prev'] = l > l.shift(1)
                
                # High lower than previous high
                df_mem['high_lower_than_prev'] = h < h.shift(1)
            
            # Guardar en MEMORY_STORE
            update_memory_df(symbol, tf, df_mem)
            
        except Exception as e:
            self.log(f"Error sincronizando MEMORY_STORE para {symbol}/{tf}: {e}", "WARNING")

    def run_cycle(self):
        #    Heartbeat                              
        register_heartbeat('forex_worker')
        
        STATE['cycle_count'] = STATE.get('cycle_count', 0) + 1
        cycle = STATE['cycle_count']
        delay = 0
        for sym in self.symbols:
            # 5m (NUEVO para Trailing SHORT)
            reactor.callLater(delay, self.request_bars, sym, '5m', 100)
            
            # 15m cada minuto
            reactor.callLater(delay + 1.0, self.request_bars, sym, '15m', 100)
            
            # 1h cada 4 ciclos (~4 min)
            if cycle % 4 == 0:
                reactor.callLater(delay + 2.0, self.request_bars, sym, '1h', 50)
            
            # 4h cada 12 ciclos (~12 min)
            if cycle % 12 == 0:
                reactor.callLater(delay + 3.0, self.request_bars, sym, '4h', 50)
            
            # 1d cada 60 ciclos (~1 hora)
            if cycle % 60 == 0:
                reactor.callLater(delay + 4.0, self.request_bars, sym, '1d', 50)

            # Snapshot real-time
            reactor.callLater(delay + 5.0, self.save_snapshot, sym)
            
            # Gestión de posiciones 5m (Trailing SHORT)
            # Solo ejecutamos si tenemos las velas cargadas (con un pequeño delay tras request_bars)
            reactor.callLater(delay + 7.0, self._manage_position_5m, sym)
            
            delay += 8.0 
        
        self.log(f'Cycle {cycle} complete. TFs updated and 5m management scheduled.')

    def _get_candles_df(self, symbol, tf):
        """Convierte la lista de velas en un DataFrame compatible."""
        key = f"{symbol}_{tf}"
        data = STATE['candles'].get(key, [])
        if not data: return None
        df = pd.DataFrame(data)
        # Renombrar para compatibilidad con el engine
        df = df.rename(columns={'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close', 'v': 'volume'})
        return df

    def _manage_position_5m(self, symbol: str):
        """
        Gestión de posiciones en ciclo rápido (5m).
        Implementa el trailing dinámico reactivo para SHORT/SELL.
        """
        try:
            # 1. Obtener posiciones abiertas del símbolo
            res = self.safe_db_execute(sb.table('forex_positions').select('*').eq('symbol', symbol).eq('status', 'open'))
            positions = res.data or []
            if not positions: return

            # 2. Obtener dataframes (15m, 5m y 4h)
            df_15m = self._get_candles_df(symbol, '15m')
            df_5m  = self._get_candles_df(symbol, '5m')
            df_4h  = self._get_candles_df(symbol, '4h')
            
            # 3. Obtener snapshot para indicadores
            snap_res = self.safe_db_execute(sb.table('market_snapshot').select('*').eq('symbol', symbol).limit(1))
            snap = snap_res.data[0] if snap_res.data else {}

            price_data = STATE['prices'].get(symbol, {})
            current_price = price_data.get('mid', 0)
            if current_price <= 0 and snap:
                current_price = snap.get('price', 0)

            if current_price <= 0: return

            for pos in positions:
                try:
                    side = pos['side'].lower()
                    is_short = side in ('short', 'sell')
                    
                    # El trailing dinámico reactivo es mandatorio para SHORT en 5m
                    # Para LONG mantenemos 15m (según requerimiento)
                    
                    # Crear objeto de estado temporal para evaluación, recuperando marcas históricas de memoria
                    h_p = STATE['highest_prices_cache'].get(pos['id']) or float(pos.get('highest_price') or pos.get('entry_price') or 0)
                    l_p = STATE['lowest_prices_cache'].get(pos['id']) or float(pos.get('lowest_price') or pos.get('entry_price') or 0)
                    highest_band = pos.get('highest_band_reached') or ''
                    bb_touched_val = 'bb_touched' in str(highest_band)
                    rule_val = pos.get('rule_code') or ''
                    
                    state = ProtectionState(
                        position_id = str(pos['id']),
                        symbol      = symbol,
                        side        = side,
                        entry_price = float(pos.get('entry_price') or 0),
                        current_sl  = float(pos.get('sl_price') or 0),
                        original_sl = float(pos.get('original_sl') or pos.get('sl_price') or 0),
                        market_type = 'forex_futures',
                        highest_price = h_p,
                        lowest_price  = l_p,
                        rule_code   = rule_val,
                        bb_touched   = bb_touched_val,
                        opened_at   = str(pos.get('opened_at') or '')
                    )

                    # Precio base para el trailing (mejor precio alcanzado)
                    if is_short:
                        best_p = state.lowest_price if state.lowest_price > 0 else state.entry_price
                    else:
                        best_p = state.highest_price if state.highest_price > 0 else state.entry_price

                    # Evaluar Trailing Stop (ApexConfluence)
                    res_trail = evaluate_trailing_stop(state, current_price, df_15m=df_15m, df_5m=df_5m, snap=snap)
                    
                    if res_trail['action'] == 'none' and not res_trail.get('update_bb_touched'):
                        # Fallback to Volatile Trailing v2
                        res_trail = evaluate_volatile_trailing_v2(
                            symbol        = symbol,
                            side          = side,
                            entry_price   = state.entry_price,
                            current_price = current_price,
                            best_price    = best_p,
                            current_sl    = state.current_sl,
                            df_15m        = df_15m,
                            df_5m         = df_5m,
                            atr_snap      = float(snap.get('atr') or 0)
                        )
                        
                    # Handle bb_touched update
                    if res_trail.get('update_bb_touched') or res_trail['action'] == 'update_bb_touched':
                        try:
                            curr_band = pos.get('highest_band_reached') or ''
                            new_band = f"{curr_band};bb_touched" if curr_band else "bb_touched"
                            self.safe_db_execute(sb.table('forex_positions').update({
                                'highest_band_reached': new_band
                            }).eq('id', pos['id']))
                            pos['highest_band_reached'] = new_band
                            state.bb_touched = True
                            self.log(f"[PROTECTION] {symbol}: bb_touched detectado. Actualizado DB.")
                        except Exception as e:
                            self.log(f"Error actualizando bb_touched para {symbol}: {e}", "WARNING")

                    if res_trail['action'] == 'update_sl':
                        new_sl = res_trail['sl_price']
                        new_tp = res_trail.get('new_tp')
                        self.log(f"[TRAILING-5M] {symbol} {side.upper()} -> Nuevo SL: {new_sl:.5f} ({res_trail['reason']})")
                        if new_tp:
                            self.log(f"[TRAILING-5M] {symbol} {side.upper()} -> Nuevo TP: {new_tp:.5f}")
                        
                        # 1. Actualizar en cTrader
                        c_id = pos.get('ctrader_pos_id')
                        if c_id:
                            self.amend_position(c_id, sl_price=new_sl, tp_price=new_tp, symbol=symbol)
                        
                        # 2. Actualizar en Supabase
                        upd_data = {'sl_price': new_sl}
                        if new_tp:
                            upd_data['tp_price'] = new_tp
                            pos['tp_price'] = new_tp
                        if is_short:
                            STATE['lowest_prices_cache'][pos['id']] = min(state.lowest_price if state.lowest_price > 0 else current_price, current_price)
                        else:
                            STATE['highest_prices_cache'][pos['id']] = max(state.highest_price, current_price)
                            
                        self.safe_db_execute(sb.table('forex_positions').update(upd_data).eq('id', pos['id']))
                        
                    elif res_trail['action'] == 'close_market':
                        self.log(f"[TRAILING-5M CLOSE] {symbol} {side.upper()} @ {current_price} | Razón: {res_trail['reason']}", "WARNING")
                        # 1. Cerrar en cTrader
                        c_id = pos.get('ctrader_pos_id')
                        if c_id:
                            self.close_position(c_id, symbol=symbol)
                        # 2. Cerrar en DB con datos reales financieros
                        try:
                            entry_px = float(pos.get('entry_price') or 0)
                            lots_qty = abs(float(pos.get('lots') or 0))
                            pip_val_usd = 10.0  # Lote estándar pips value
                            from app.strategy.capital_protection import PIP_SIZES
                            pip_size_val = PIP_SIZES.get(symbol, 0.0001)
                            is_short_pos = side.lower() in ('short', 'sell')
                            pips_pnl_calc = (entry_px - current_price) / pip_size_val if is_short_pos else (current_price - entry_px) / pip_size_val
                            pnl_usd_calc = pips_pnl_calc * pip_val_usd * lots_qty
                            
                            upd_fields = {
                                'status': 'closed', 
                                'current_price': current_price,
                                'pnl_pips': round(pips_pnl_calc, 1),
                                'pnl_usd': round(pnl_usd_calc, 2),
                                'closed_at': datetime.now(timezone.utc).isoformat(), 
                                'close_reason': res_trail['reason']
                            }
                            
                            # Registrar en capital manager
                            try:
                                from app.core.capital_manager import register_realized_pnl
                                register_realized_pnl('forex', round(pnl_usd_calc, 2))
                            except Exception:
                                pass
                        except Exception as calc_err:
                            self.log(f"Error calculando PnL de cierre: {calc_err}", "ERROR")
                            upd_fields = {
                                'status': 'closed', 
                                'current_price': current_price,
                                'closed_at': datetime.now(timezone.utc).isoformat(), 
                                'close_reason': res_trail['reason']
                            }
                            
                        self.safe_db_execute(sb.table('forex_positions').update(upd_fields).eq('id', pos['id']))
                        
                        # 3. Si no tocó BB, re-entrar con órdenes límite!
                        if not res_trail.get('bb_touched', False):
                            qty = abs(float(pos.get('lots') or 0))
                            self.trigger_forex_reentry_standalone(symbol, side, qty, df_15m)
                        continue
                    
                    # --- NUEVO: CIERRE PROACTIVO (AaEXT/AaEXH) ---
                    proactive_res = evaluate_proactive_exit(
                        position      = pos,
                        current_price = current_price,
                        snap          = snap,
                        df_4h         = df_4h,
                        market_type   = 'forex_futures'
                    )
                    
                    if proactive_res['should_close']:
                        self.log(f"[PROACTIVE-EXIT] {symbol} {side.upper()} @ {current_price} | Regla: {proactive_res['rule_code']} | Razón: {proactive_res['reason']}", "WARNING")
                        # Cerrar en cTrader
                        c_id = pos.get('ctrader_pos_id')
                        if c_id:
                            self.close_position(c_id, symbol=symbol)
                        # Cerrar en DB con datos reales financieros
                        try:
                            entry_px = float(pos.get('entry_price') or 0)
                            lots_qty = abs(float(pos.get('lots') or 0))
                            pip_val_usd = 10.0
                            from app.strategy.capital_protection import PIP_SIZES
                            pip_size_val = PIP_SIZES.get(symbol, 0.0001)
                            is_short_pos = side.lower() in ('short', 'sell')
                            pips_pnl_calc = (entry_px - current_price) / pip_size_val if is_short_pos else (current_price - entry_px) / pip_size_val
                            pnl_usd_calc = pips_pnl_calc * pip_val_usd * lots_qty
                            
                            upd_fields = {
                                'status': 'closed', 
                                'current_price': current_price,
                                'pnl_pips': round(pips_pnl_calc, 1),
                                'pnl_usd': round(pnl_usd_calc, 2),
                                'closed_at': datetime.now(timezone.utc).isoformat(), 
                                'close_reason': proactive_res.get('reason') or proactive_res.get('rule_code'),
                                'exit_reason': proactive_res['rule_code']
                            }
                            
                            try:
                                from app.core.capital_manager import register_realized_pnl
                                register_realized_pnl('forex', round(pnl_usd_calc, 2))
                            except Exception:
                                pass
                        except Exception as calc_err:
                            self.log(f"Error calculando PnL de cierre proactivo: {calc_err}", "ERROR")
                            upd_fields = {
                                'status': 'closed', 
                                'current_price': current_price,
                                'closed_at': datetime.now(timezone.utc).isoformat(), 
                                'exit_reason': proactive_res['rule_code']
                            }
                            
                        self.safe_db_execute(sb.table('forex_positions').update(upd_fields).eq('id', pos['id']))
                        continue

                    else:
                        # Si no hay update de SL, al menos actualizamos en memoria local el mejor precio si mejoró
                        if is_short:
                            low = min(state.lowest_price if state.lowest_price > 0 else current_price, current_price)
                            if low < (state.lowest_price if state.lowest_price > 0 else 999999):
                                STATE['lowest_prices_cache'][pos['id']] = low
                        else:
                            high = max(state.highest_price, current_price)
                            if high > state.highest_price:
                                STATE['highest_prices_cache'][pos['id']] = high
                except Exception as pos_err:
                    import traceback
                    self.log(f"Error managing position ID {pos.get('id')} ({symbol}): {pos_err}\n{traceback.format_exc()}", "ERROR")
                    continue

        except Exception as e:
            self.log(f"Error en _manage_position_5m para {symbol}: {e}", "ERROR")
            self.log(traceback.format_exc(), "ERROR")

    def save_snapshot(self, symbol):
        try:
            key = f"{symbol}_15m"; data = STATE['candles'].get(key, [])
            if not data or len(data) < 20: 
                self.log(f"Snapshot abortado para {symbol}: Datos insuficientes ({len(data)} velas)", "WARNING")
                return
            df = pd.DataFrame(data)
            # V7: adjust=False para fórmula EMA estándar financiera (compatible con TradingView/cTrader)
            df['ema20'] = df['c'].ewm(span=20, adjust=False).mean()
            df['ema9']  = df['c'].ewm(span=9, adjust=False).mean()
            df['ema3']  = df['c'].ewm(span=3, adjust=False).mean()
            df['bb_up']  = df['ema20'] + (df['c'].rolling(20).std() * 2)
            df['bb_low'] = df['ema20'] - (df['c'].rolling(20).std() * 2)
            
            df['tr'] = np.maximum(df['h'] - df['l'], np.maximum(abs(df['h'] - df['c'].shift(1)), abs(df['l'] - df['c'].shift(1))))
            df['atr'] = df['tr'].rolling(window=14).mean()
            # Usar implementacion interna (ya no requiere renombrar columnas)
            calculate_parabolic_sar(df)
            
            # --- MACD 4C para Pinescript Signal ---
            df['macd_fast'] = df['c'].ewm(span=12, adjust=False).mean()
            df['macd_slow'] = df['c'].ewm(span=26, adjust=False).mean()
            df['macd'] = df['macd_fast'] - df['macd_slow']
            df['macd_prev'] = df['macd'].shift(1)
            
            # 1: Up Strong, 2: Up Weak, 3: Down Strong, 4: Down Weak
            df['macd_4c'] = np.select(
                [(df['macd'] > 0) & (df['macd'] > df['macd_prev']),
                 (df['macd'] > 0) & (df['macd'] <= df['macd_prev']),
                 (df['macd'] < 0) & (df['macd'] < df['macd_prev']),
                 (df['macd'] < 0) & (df['macd'] >= df['macd_prev'])],
                [1, 2, 3, 4], default=0
            )
            df['macd_buy'] = (df['macd_4c'] == 4) & (df['macd_4c'].shift(1) == 3)
            df['macd_sell'] = (df['macd_4c'] == 2) & (df['macd_4c'].shift(1) == 1)

            # --- ADX ---
            df['dm_plus'] = np.where((df['h'] - df['h'].shift(1)) > (df['l'].shift(1) - df['l']), np.maximum(df['h'] - df['h'].shift(1), 0), 0)
            df['dm_minus'] = np.where((df['l'].shift(1) - df['l']) > (df['h'] - df['h'].shift(1)), np.maximum(df['l'].shift(1) - df['l'], 0), 0)
            df['tr_14'] = df['tr'].rolling(window=14).mean()
            df['di_plus'] = 100 * (df['dm_plus'].rolling(window=14).mean() / df['tr_14'])
            df['di_minus'] = 100 * (df['dm_minus'].rolling(window=14).mean() / df['tr_14'])
            df['dx'] = 100 * abs(df['di_plus'] - df['di_minus']) / (df['di_plus'] + df['di_minus'] + 1e-10)
            df['adx'] = df['dx'].rolling(window=14).mean()
            
            last = df.iloc[-1]
            candle_price = float(last['c'])
            spot_price = STATE['prices'].get(symbol, {}).get('mid', 0)

            # FIX: Validate spot price against candle price
            # If spot is < 50% of candle price, it's corrupted (partial update bug)
            if spot_price > 0 and candle_price > 0:
                ratio = spot_price / candle_price
                if 0.5 < ratio < 2.0:
                    price = spot_price  # Spot looks valid
                else:
                    price = candle_price  # Fallback to candle
                    self.log(f"[WARN] Spot price {spot_price:.5f} vs candle {candle_price:.5f} for {symbol} - using candle", "WARNING")
            elif spot_price > 0:
                price = spot_price
            else:
                price = candle_price

            # --- SAFE DATA EXTRACTION ---
            def safe_f(val, default=0.0):
                try:
                    if val is None or (isinstance(val, float) and np.isnan(val)): return default
                    return float(val)
                except: return default

            ema20 = safe_f(last.get('ema20'))
            ema9  = safe_f(last.get('ema9'))
            ema3  = safe_f(last.get('ema3'))
            atr   = safe_f(last.get('atr'))
            adx   = safe_f(last.get('adx'), 25.0)

            # Bollinger Expansion detection
            prev = df.iloc[-2] if len(df) >= 2 else last
            bb_expanding = bool((last.get('bb_up', 0) > prev.get('bb_up', 0)) and (last.get('bb_low', 0) < prev.get('bb_low', 0)))
            
            # EMA Exhaustion detection
            ema_dist = abs(ema3 - ema9) / (ema9 + 1e-10) * 100
            ema_dist_avg = df['ema3'].sub(df['ema9']).abs().div(df['ema9'].add(1e-10)).mul(100).rolling(10).mean().iloc[-1]
            ema_exhaustion = bool(ema_dist < (ema_dist_avg * 0.3))

            multipliers = [1.0, 1.618, 2.618, 3.618, 4.236, 5.618]
            zone = 0
            if atr > 0:
                for i in range(6, 0, -1):
                    if price > ema20 + (atr * multipliers[i-1]): zone = i; break
                    if price < ema20 - (atr * multipliers[i-1]): zone = -i; break

            # Eliminado upsert duplicado síncrono propenso a errores.
            # Los datos se de-duplican y se guardan de forma segura en la sección inferior.

            # --- CALCULO DE MTF SCORE ---
            mtf_score = 0.0
            tfs_checked = 0
            for tf_suffix in ['15m', '1h', '4h', '1d']:
                tf_key = f"{symbol}_{tf_suffix}"
                tf_data = STATE['candles'].get(tf_key, [])
                if len(tf_data) >= 10:
                    try:
                        tf_df = pd.DataFrame(tf_data)
                        tf_ema20 = tf_df['c'].ewm(span=20, adjust=False).mean().iloc[-1]
                        if price > tf_ema20: mtf_score += 0.25
                        else: mtf_score -= 0.25
                        tfs_checked += 1
                    except: pass
            
            # Calculate Fibonacci band levels
            fib_bands = {}
            if atr > 0:
                for i, m in enumerate(multipliers, 1):
                    fib_bands[f'upper_{i}'] = float(ema20 + (atr * m))
                    fib_bands[f'lower_{i}'] = float(ema20 - (atr * m))

            # Calculate SAR from 4h data if available
            sar_15m = safe_f(last.get('sar'))
            sar_4h = sar_15m  
            sar_trend_4h = 0
            key_4h = f"{symbol}_4h"
            data_4h = STATE['candles'].get(key_4h, [])
            if data_4h and len(data_4h) > 5:
                try:
                    df_4h = pd.DataFrame(data_4h)
                    df_4h['basis'] = df_4h['c'].ewm(span=20, adjust=False).mean()
                    df_4h['tr'] = np.maximum(df_4h['h'] - df_4h['l'], np.maximum(abs(df_4h['h'] - df_4h['c'].shift(1)), abs(df_4h['l'] - df_4h['c'].shift(1))))
                    df_4h['atr'] = df_4h['tr'].rolling(window=14).mean()
                    calculate_parabolic_sar(df_4h)
                    last_4h = df_4h.iloc[-1]
                    sar_4h = safe_f(last_4h.get('sar'))
                    sar_trend_4h = int(last_4h.get('sar_trend', 0))
                except: pass

            dist_basis = abs(price - ema20) / ema20 * 100 if ema20 > 0 else 0

            snap = {
                'symbol': symbol,
                'price': float(price),
                'basis': float(ema20),
                'atr': float(atr),  # Added atr for consistency with stocks_scheduler
                'fibonacci_zone': int(zone),
                'dist_basis_pct': round(dist_basis, 4),
                'mtf_score': float(mtf_score),
                'sar_4h': float(sar_4h),
                'sar_trend_4h': sar_trend_4h,
                'sar_15m': sar_15m,
                'sar_trend_15m': 1 if last.get('sar_trend', 0) > 0 else -1,
                'sar_phase': 'long' if sar_trend_4h > 0 else ('short' if sar_trend_4h < 0 else ('long' if price > sar_15m else 'short')),
                'updated_at': datetime.now(timezone.utc).isoformat(),
                'bb_expanding': bb_expanding,
                'adx': adx,
                'pinescript_signal': 'Buy' if last.get('macd_buy') else ('Sell' if last.get('macd_sell') else None)
            }

            # Add Fibonacci bands
            snap.update(fib_bands)

            query = sb.table('market_snapshot').upsert(snap, on_conflict='symbol')
            
            def safe_upsert(q, s):
                try:
                    return q.execute()
                except Exception as e:
                    err_str = str(e).lower()
                    if "column" in err_str and ("ema_" in err_str or "ema_exhaustion" in err_str):
                        # Limpieza de columnas conflictivas que no existen en DB
                        for col in ['ema_3', 'ema_9', 'ema_20', 'ema_exhaustion', 'ema20_phase']:
                            if col in s: del s[col]
                        return sb.table('market_snapshot').upsert(s, on_conflict='symbol').execute()

                    raise e

            threads.deferToThread(safe_upsert, query, snap).addErrback(
                lambda f: self.log(f"Error async db snapshot: {f.getErrorMessage()}", "ERROR")
            )
        except Exception as e: 
            self.log(f"Error snap {symbol}:\n{traceback.format_exc()}", "ERROR")

if __name__ == '__main__':
    worker = StandaloneForexWorker(); worker.start()
