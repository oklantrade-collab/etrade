"""
eTrader — Forex Scheduler (IC Markets via cTrader)
====================================================
Scheduler para operaciones Forex replicando la arquitectura
del scheduler de Crypto.

Opera con los mismos ciclos:
    5m  → gestión de posiciones y smart exits
    15m → análisis completo, indicadores y señales
    4h  → swing trade y reglas Aa31/Bb31

Usa el mismo Strategy Engine v1.0 y las mismas reglas
Aa/Bb/Cc/Dd. Solo cambia el proveedor de datos (CTrader
en lugar de Binance).
"""
import asyncio
import json
import os
import sys
import time
from datetime import datetime, timezone
from typing import Optional

import pandas as pd
import numpy as np

# Path setup
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from app.core.logger import log_info, log_error, log_warning, log_debug
from app.core.supabase_client import get_supabase
from app.core.config import settings, STRUCTURE_CONFIG
from app.core.memory_store import (
    BOT_STATE, update_memory_df, get_memory_df, MEMORY_STORE,
    update_current_candle_close, MARKET_SNAPSHOT_CACHE
)

# Analysis & Indicators
from app.analysis.indicators_v2 import calculate_all_indicators
from app.analysis.fibonacci_bb import fibonacci_bollinger, extract_fib_levels, get_next_fibonacci_target
from app.analysis.parabolic_sar import calculate_parabolic_sar, analyze_structure
from app.strategy.volume_spike import detect_spike
from app.strategy.mtf_scorer import calculate_mtf_score
from app.strategy.market_regime import classify_market_risk, update_regime_if_changed

# Strategy Engine
from app.strategy.strategy_engine import StrategyEngine
from app.core.symbol_state import SymbolStateMachine

sm = SymbolStateMachine.get_instance()

# Position management
from app.core.position_sizing import calculate_position_size, can_open_short, calculate_sl_tp
from app.core.position_monitor import (
    _execute_paper_close,
    _execute_paper_partial_close,
    _execute_paper_open,
    check_signal_reversal,
)
from app.strategy.band_exit import evaluate_band_exit

# Alerts
from app.workers.alerts_service import send_telegram_message
from app.workers.performance_monitor import check_performance_alerts
from app.strategy.macro_filter import check_usd_exposure_filter

# Forex config
from app.config.forex_config import (
    FOREX_SYMBOLS, FOREX_TIMEFRAMES, PIP_SIZES,
    LOT_CONFIG, FOREX_RISK_CONFIG, CTRADER_CONFIG
)

# Provider
from app.execution.provider_factory import create_provider
from app.execution.providers.ctrader_provider import CTraderProtobufProvider

MODULE = "forex_scheduler"

# ── State ──────────────────────────────────────────
_forex_provider: Optional[CTraderProtobufProvider] = None
_forex_cycle_count = 0


# ══════════════════════════════════════════════════
#  WARM-UP (Phase 0)
# ══════════════════════════════════════════════════

async def warm_up_forex(symbols: list, timeframes: list, provider: CTraderProtobufProvider):
    """
    Precalentar MEMORY_STORE con datos Forex de IC Markets.
    Descarga velas historicas + calcula todos los indicadores.
    """
    log_info(MODULE, f"Precalentando Forex: {len(symbols)} simbolos x {len(timeframes)} TFs")
    start = datetime.now()

    tasks = []
    for symbol in symbols:
        for tf in timeframes:
            tasks.append(_warm_up_forex_symbol_tf(symbol, tf, provider))

    results = await asyncio.gather(*tasks, return_exceptions=True)
    for r in results:
        if isinstance(r, Exception):
            log_error(MODULE, f"Error en warm-up: {r}")

    elapsed = (datetime.now() - start).total_seconds()
    log_info(MODULE, f"Precalentamiento Forex completado: {elapsed:.1f}s")


async def _warm_up_forex_symbol_tf(symbol: str, tf: str, provider: CTraderProtobufProvider):
    """Descargar y procesar un symbol/tf."""
    try:
        df = await provider.get_ohlcv(symbol, tf, limit=300)
        if df is not None and not df.empty:
            loop = asyncio.get_running_loop()
            df = await loop.run_in_executor(None, calculate_all_indicators, df, BOT_STATE.config_cache)
            update_memory_df(symbol, tf, df)
            
            # Rehidratar caché en memoria (Evita base de datos pero soluciona el reinicio)
            if tf == '15m':
                last_row = df.iloc[-1]
                MARKET_SNAPSHOT_CACHE.setdefault(symbol, {}).update({
                    'price': float(last_row['close']),
                    'ema_3': float(last_row.get('ema1', 0) if last_row.get('ema1') is not None else 0),
                    'ema_9': float(last_row.get('ema2', 0) if last_row.get('ema2') is not None else 0),
                    'ema_20': float(last_row.get('ema3', 0) if last_row.get('ema3') is not None else 0),
                    'ema_50': float(last_row.get('ema4', 0) if last_row.get('ema4') is not None else 0),
                    'rsi_14': float(last_row.get('rsi1', 0) if last_row.get('rsi1') is not None else 0),
                    'atr': float(last_row.get('atr', 0) if last_row.get('atr') is not None else 0),
                    'adx': float(last_row.get('adx', 0) if last_row.get('adx') is not None else 0),
                    'macd_histogram': float(last_row.get('macd_hist', 0) if last_row.get('macd_hist') is not None else 0),
                    'updated_at': datetime.now(timezone.utc).isoformat()
                })
                
            log_info(MODULE, f"  {symbol}/{tf}: {len(df)} velas cargadas")
        else:
            log_warning(MODULE, f"  {symbol}/{tf}: sin datos")
    except Exception as e:
        log_error(MODULE, f"  Error warm-up {symbol}/{tf}: {e}")


# ══════════════════════════════════════════════════
#  MARKET SNAPSHOT (Forex)
# ══════════════════════════════════════════════════

async def write_forex_snapshot(
    symbol: str,
    df: pd.DataFrame,
    regime: dict,
    spike: dict,
    mtf_score: float,
    sb
):
    """
    Escribe el snapshot de mercado Forex en Supabase.
    Replica la logica de write_market_snapshot del scheduler crypto.
    """
    try:
        if df is None or df.empty:
            return

        last = df.iloc[-1]

        # Extraer niveles Fibonacci
        try:
            fib_levels = extract_fib_levels(df)
        except (KeyError, ValueError, AttributeError):
            df_15m_mem = MEMORY_STORE.get(symbol, {}).get('15m', {}).get('df')
            if df_15m_mem is not None and 'basis' in df_15m_mem.columns:
                fib_levels = extract_fib_levels(df_15m_mem)
            else:
                fib_levels = {
                    'zone': 0, 'basis': 0.0,
                    'upper_1': 0.0, 'upper_2': 0.0, 'upper_3': 0.0,
                    'upper_4': 0.0, 'upper_5': 0.0, 'upper_6': 0.0,
                    'lower_1': 0.0, 'lower_2': 0.0, 'lower_3': 0.0,
                    'lower_4': 0.0, 'lower_5': 0.0, 'lower_6': 0.0,
                }

        # SAR 4H
        sar_value = 0
        sar_trend = 0
        sar_phase = 'neutral'
        prev_trend = 0

        # Leer fase anterior
        try:
            prev_res = sb.table('market_snapshot').select('sar_trend_4h').eq('symbol', symbol).maybe_single().execute()
            if prev_res.data:
                prev_trend = int(prev_res.data.get('sar_trend_4h', 0))
        except:
            pass

        df_4h = MEMORY_STORE.get(symbol, {}).get('4h', {}).get('df')
        if df_4h is not None and not df_4h.empty:
            df_4h_sar = calculate_parabolic_sar(df_4h.copy())
            last_4h = df_4h_sar.iloc[-1]
            sar_trend = int(last_4h['sar_trend'])
            sar_value = float(last_4h['sar'])

            if sar_trend > 0:
                sar_phase = 'long'
            elif sar_trend < 0:
                sar_phase = 'short'

            MEMORY_STORE[symbol]['sar'] = {
                'phase': sar_phase,
                'value_4h': sar_value,
                'trend_4h': sar_trend,
                'changed_at': None,
            }

        sar_changed = (prev_trend != 0 and sar_trend != 0 and sar_trend != prev_trend)
        changed_at_iso = None
        if sar_changed:
            changed_at_iso = datetime.now(timezone.utc).isoformat()
            MEMORY_STORE[symbol]['sar']['changed_at'] = changed_at_iso
            log_info('SAR_FOREX', f"CAMBIO SAR {symbol}: {prev_trend} -> {sar_trend}")

        # SAR 15m
        sar_15m = None
        sar_trend_15m = 0
        sar_ini_high_15m = False
        sar_ini_low_15m = False
        p_signal_15m = None

        df_15m_mem = MEMORY_STORE.get(symbol, {}).get('15m', {}).get('df')
        last_15m = None
        if df_15m_mem is not None and not df_15m_mem.empty:
            df_15m_sar = calculate_parabolic_sar(df_15m_mem.copy())
            last_15m = df_15m_sar.iloc[-1]
            sar_15m = float(last_15m.get('sar', 0))
            sar_trend_15m = int(last_15m.get('sar_trend', 0))
            sar_ini_high_15m = bool(last_15m.get('sar_ini_high', False))
            sar_ini_low_15m = bool(last_15m.get('sar_ini_low', False))
            p_signal_15m = str(last_15m.get('last_pinescript_signal', '') or '')

        # Estructura 15m
        cfg_struct = STRUCTURE_CONFIG
        if df_15m_mem is not None and not df_15m_mem.empty:
            df_15m_sar_s = calculate_parabolic_sar(df_15m_mem.copy())
            struct_15m = analyze_structure(
                df=df_15m_sar_s,
                sar_col='sar_trend',
                n_confirm=cfg_struct['velas_confirmacion'],
                umbral_low=cfg_struct['umbral_lower_low'],
                umbral_high=cfg_struct['umbral_higher_high'],
            )
        else:
            struct_15m = {
                'structure': 'unknown', 'allow_long': True,
                'allow_short': True, 'reverse_signal': False,
                'reason': 'No 15m data',
            }

        # Estructura 4h
        if df_4h is not None and not df_4h.empty:
            df_4h_sar_s = calculate_parabolic_sar(df_4h.copy())
            struct_4h = analyze_structure(
                df=df_4h_sar_s,
                sar_col='sar_trend',
                n_confirm=cfg_struct['velas_confirmacion'],
                umbral_low=cfg_struct['umbral_lower_low'],
                umbral_high=cfg_struct['umbral_higher_high'],
            )
        else:
            struct_4h = {
                'structure': 'unknown', 'allow_long': True,
                'allow_short': True, 'reverse_signal': False,
                'reason': 'No 4h data',
            }

        upsert_data = {
            'symbol':            symbol,
            'price':             float(last['close']),
            'fibonacci_zone':    int(fib_levels.get('zone', 0)),
            'basis':             float(fib_levels.get('basis', 0)),
            'upper_1':           float(fib_levels.get('upper_1', 0)),
            'upper_2':           float(fib_levels.get('upper_2', 0)),
            'upper_3':           float(fib_levels.get('upper_3', 0)),
            'upper_4':           float(fib_levels.get('upper_4', 0)),
            'upper_5':           float(fib_levels.get('upper_5', 0)),
            'upper_6':           float(fib_levels.get('upper_6', 0)),
            'lower_1':           float(fib_levels.get('lower_1', 0)),
            'lower_2':           float(fib_levels.get('lower_2', 0)),
            'lower_3':           float(fib_levels.get('lower_3', 0)),
            'lower_4':           float(fib_levels.get('lower_4', 0)),
            'lower_5':           float(fib_levels.get('lower_5', 0)),
            'lower_6':           float(fib_levels.get('lower_6', 0)),
            'dist_basis_pct':    float(
                abs(float(last['close']) - float(last.get('basis', last['close'])))
                / float(last.get('basis', last['close'])) * 100
                if float(last.get('basis', 0)) > 0 else 0
            ),
            'mtf_score':         round(float(mtf_score), 4),
            'ema20_phase':       str(last.get('ema20_phase', '')),
            'adx':               float(last.get('adx', 0)),
            'atr':               float(last.get('atr', 0)),
            'regime':            regime.get('category', ''),
            'risk_score':        regime.get('risk_score', 0),
            'spike_detected':    spike.get('detected', False),
            'spike_ratio':       spike.get('ratio', 0),
            'spike_direction':   spike.get('direction', ''),
            'sar_4h':            sar_value,
            'sar_trend_4h':      sar_trend,
            'sar_phase':         sar_phase,
            'sar_15m':           sar_15m,
            'sar_trend_15m':     sar_trend_15m,
            'sar_ini_high_15m':  sar_ini_high_15m,
            'sar_ini_low_15m':   sar_ini_low_15m,
            'pinescript_signal': p_signal_15m,
            'pinescript_signal_age': int(last_15m.get('signal_age', 0)) if last_15m is not None else 0,
            # Estructura
            'structure_15m':         struct_15m['structure'],
            'allow_long_15m':        struct_15m['allow_long'],
            'allow_short_15m':       struct_15m['allow_short'],
            'reverse_signal_15m':    struct_15m['reverse_signal'],
            'structure_reason_15m':  struct_15m['reason'],
            'structure_4h':          struct_4h['structure'],
            'allow_long_4h':         struct_4h['allow_long'],
            'allow_short_4h':        struct_4h['allow_short'],
            'reverse_signal_4h':     struct_4h['reverse_signal'],
            'structure_reason_4h':   struct_4h['reason'],
            'bb_expanding':          bool(last.get('bb_expanding', False)),
            'updated_at':            datetime.now(timezone.utc).isoformat(),
        }

        # Extraer indicadores para el caché en memoria (no están en la tabla DB)
        upsert_data['ema_3'] = float(last.get('ema1', last.get('ema_3', 0)))
        upsert_data['ema_9'] = float(last.get('ema2', last.get('ema_9', 0)))
        upsert_data['ema_20'] = float(last.get('ema3', last.get('ema_20', 0)))
        upsert_data['ema_50'] = float(last.get('ema4', last.get('ema_50', 0)))
        upsert_data['rsi_14'] = float(last.get('rsi_14', last.get('rsi', 50)))
        upsert_data['macd_histogram'] = float(last.get('macd_histogram', last.get('macd', 0)))
        
        # Calcular Bollinger Bands estándar (20, 2)
        try:
            rolling_mean = df['close'].rolling(20).mean()
            rolling_std = df['close'].rolling(20).std()
            upsert_data['bb_upper'] = float(rolling_mean.iloc[-1] + 2 * rolling_std.iloc[-1])
            upsert_data['bb_lower'] = float(rolling_mean.iloc[-1] - 2 * rolling_std.iloc[-1])
        except Exception:
            upsert_data['bb_upper'] = 0.0
            upsert_data['bb_lower'] = 0.0

        # Para compatibilidad con algunos scripts que leen 'rsi_14_prev'
        try:
            if len(df) >= 2:
                prev_row = df.iloc[-2]
                upsert_data['rsi_14_prev'] = float(prev_row.get('rsi_14', prev_row.get('rsi', 50)))
        except:
            pass

        # Preparar datos para base de datos (excluyendo campos solo de caché)
        db_data = upsert_data.copy()
        for k in ['ema_3', 'ema_9', 'ema_20', 'ema_50', 'rsi_14', 'rsi_14_prev', 'macd_histogram', 'bb_upper', 'bb_lower']:
            db_data.pop(k, None)

        if sar_changed:
            db_data['sar_phase_changed_at'] = changed_at_iso

        sb.table('market_snapshot').upsert(db_data).execute()
        
        # Actualizar caché en memoria completo (incluyendo indicadores rápidos)
        MARKET_SNAPSHOT_CACHE[symbol] = upsert_data
        log_info('SNAPSHOT_FX', f'Snapshot OK: {symbol} mtf={mtf_score:.4f}')

    except Exception as e:
        log_error('SNAPSHOT_FX', f'FALLO snapshot {symbol}: {e}')


# ══════════════════════════════════════════════════
#  CANDLE UPSERT (Forex)
# ══════════════════════════════════════════════════

async def upsert_forex_candles(symbol: str, timeframe: str, df: pd.DataFrame, sb):
    """Sindronizar velas Forex con market_candles."""
    if df is None or df.empty:
        return
    try:
        rows = []
        sub_df = df.tail(5)

        for idx, r in sub_df.iterrows():
            open_time = idx
            if hasattr(open_time, 'tzinfo') and open_time.tzinfo is None:
                open_time = open_time.tz_localize('UTC')
            if hasattr(open_time, 'isoformat'):
                open_time = open_time.isoformat()
            else:
                open_time = str(open_time)

            rows.append({
                'symbol':    symbol,
                'exchange':  'icmarkets',
                'timeframe': timeframe,
                'open_time': open_time,
                'open':      float(r['open']),
                'high':      float(r['high']),
                'low':       float(r['low']),
                'close':     float(r['close']),
                'volume':    float(r.get('volume') or 0),
                'is_closed': True,
                'basis':     float(r.get('basis', 0) or 0) if pd.notna(r.get('basis')) else None,
                'upper_6':   float(r.get('upper_6', 0) or 0) if pd.notna(r.get('upper_6')) else None,
                'lower_6':   float(r.get('lower_6', 0) or 0) if pd.notna(r.get('lower_6')) else None,
                'sar':       float(r.get('sar', 0) or 0) if pd.notna(r.get('sar')) else None,
                'sar_trend': int(r.get('sar_trend', 0) or 0) if pd.notna(r.get('sar_trend')) else None,
                'pinescript_signal': str(r.get('pinescript_signal', ''))
                    if r.get('pinescript_signal') in ('Buy', 'Sell') else None,
            })

        if rows:
            sb.table('market_candles').upsert(
                rows,
                on_conflict='symbol,exchange,timeframe,open_time'
            ).execute()
            log_info('CANDLES_FX', f"Upsert {len(rows)} velas {symbol}/{timeframe}")

    except Exception as e:
        log_error('CANDLES_FX', f"Error upsert {symbol}/{timeframe}: {e}")


# ══════════════════════════════════════════════════
#  FOREX POSITION OPENING
# ══════════════════════════════════════════════════

# ── TP Dinámico con Fibonacci ─────────────────────
# Mínimo ratio Riesgo:Beneficio aceptable por símbolo
MIN_TP_RR_RATIO = {
    'EURUSD': 1.5,
    'GBPUSD': 1.5,
    'USDJPY': 1.5,
    'XAUUSD': 1.2,
}
# Porcentaje de la distancia a la banda para el TP (95% = no exigir toque exacto)
TP_BAND_PCT = 0.95
# Bandas Fibonacci a evaluar (de más cerca a más lejos)
TP_BANDS_LONG  = ['upper_1', 'upper_2', 'upper_3', 'upper_4', 'upper_5', 'upper_6']
TP_BANDS_SHORT = ['lower_1', 'lower_2', 'lower_3', 'lower_4', 'lower_5', 'lower_6']


def _find_dynamic_tp(symbol, direction, entry_price, sl_price, snap, pip_size, atr):
    """
    Busca la primera banda de Fibonacci cuya distancia al entry
    supere el mínimo de RR ratio respecto al SL.
    Si ninguna banda cumple, usa un TP fijo basado en sl_pips × min_rr.
    """
    min_rr = MIN_TP_RR_RATIO.get(symbol, 1.5)
    sl_distance_pips = abs(entry_price - sl_price) / pip_size
    min_tp_pips = sl_distance_pips * min_rr

    bands = TP_BANDS_LONG if direction == 'long' else TP_BANDS_SHORT

    for band_name in bands:
        band_price = float(snap.get(band_name) or 0)
        if band_price <= 0:
            continue

        # Distancia de la banda al entry (en pips)
        if direction == 'long':
            tp_distance_pips = (band_price - entry_price) / pip_size
        else:
            tp_distance_pips = (entry_price - band_price) / pip_size

        # La banda debe estar del lado correcto (ganancia positiva)
        if tp_distance_pips <= 0:
            continue

        # Usar el 95% de la distancia a la banda
        effective_tp_pips = tp_distance_pips * TP_BAND_PCT

        if effective_tp_pips >= min_tp_pips:
            # Calcular el precio TP al 95% de la banda
            if direction == 'long':
                tp_price = entry_price + (effective_tp_pips * pip_size)
            else:
                tp_price = entry_price - (effective_tp_pips * pip_size)

            rr_actual = effective_tp_pips / sl_distance_pips if sl_distance_pips > 0 else 0
            log_info(MODULE,
                f"TP DINÁMICO [{symbol}]: Banda {band_name} seleccionada. "
                f"SL={sl_distance_pips:.0f} pips, TP={effective_tp_pips:.0f} pips, "
                f"RR=1:{rr_actual:.1f}"
            )
            return tp_price

    # Fallback: si ninguna banda cumple, usar RR mínimo fijo
    fallback_tp_pips = sl_distance_pips * min_rr
    if direction == 'long':
        tp_fallback = entry_price + (fallback_tp_pips * pip_size)
    else:
        tp_fallback = entry_price - (fallback_tp_pips * pip_size)

    log_info(MODULE,
        f"TP DINÁMICO [{symbol}]: Ninguna banda cumple RR mínimo ({min_rr}). "
        f"Usando fallback: {fallback_tp_pips:.0f} pips (SL={sl_distance_pips:.0f} pips)"
    )
    return tp_fallback


def calculate_forex_sl_tp(
    symbol: str,
    direction: str,
    entry_price: float,
    snap: dict = None,
) -> dict:
    """
    Calcula SL/TP en precio usando bandas de Fibonacci.
    TP Dinámico: busca la primera banda que cumpla un RR mínimo.
    """
    pip_size = PIP_SIZES.get(symbol, 0.0001)
    
    if snap:
        u1 = float(snap.get('upper_1') or 0)
        l1 = float(snap.get('lower_1') or 0)
        atr = (u1 - l1) / 3.236 if (u1 > 0 and l1 > 0) else (20 * pip_size)
        
        if direction == 'long':
            sl = float(snap.get('lower_6') or (entry_price - 50 * pip_size)) - (0.5 * atr)
        else:
            sl = float(snap.get('upper_6') or (entry_price + 50 * pip_size)) + (0.5 * atr)
        
        tp = _find_dynamic_tp(symbol, direction, entry_price, sl, snap, pip_size, atr)
    else:
        # Fallback si no hay snapshot
        sl_pips = FOREX_RISK_CONFIG['sl_pips_default']
        tp_pips = sl_pips * FOREX_RISK_CONFIG['tp_rr_ratio']
        if direction == 'long':
            sl, tp = entry_price - (sl_pips * pip_size), entry_price + (tp_pips * pip_size)
        else:
            sl, tp = entry_price + (sl_pips * pip_size), entry_price - (tp_pips * pip_size)

    return {
        'sl_price': round(sl, 6),
        'tp_price': round(tp, 6),
        'sl_pips': abs(entry_price - sl) / pip_size,
    }


def calculate_forex_lot_size(
    symbol: str,
    capital_usd: float,
    risk_pct: float,
    sl_pips: float,
    leverage: int = 100,
) -> dict:
    """
    Calcula tamano de lote Forex basado en riesgo.
    formula: lots = risk_usd / (sl_pips * pip_value)
    """
    pip_size = PIP_SIZES.get(symbol, 0.0001)
    risk_usd = capital_usd * (risk_pct / 100.0)

    # Pip value para 1 lote estandar (100,000 unidades)
    pip_value = pip_size * 100_000

    if sl_pips > 0 and pip_value > 0:
        lots = risk_usd / (sl_pips * pip_value)
    else:
        lots = LOT_CONFIG['micro_lot']

    # Redondear al step mas cercano
    step = LOT_CONFIG['lot_step']
    lots = max(LOT_CONFIG['min_lot'], round(lots / step) * step)

    return {
        'lotes': round(lots, 2),
        'risk_usd': round(risk_usd, 2),
        'pip_value': pip_value,
        'pip_size': pip_size,
    }


async def open_forex_position(
    symbol: str,
    signal: dict,
    price: float,
    provider: CTraderProtobufProvider,
    sb,
):
    """
    Abrir posicion Forex via cTrader.
    Replica la logica de _execute_paper_open para Crypto.
    """
    direction = signal['direction']
    rule_code = signal['rule_code']

    # === ESCUDO DE SEGURIDAD ESTRICTO ===
    from app.core.safety_manager import validate_signal
    snap = MARKET_SNAPSHOT_CACHE.get(symbol, {})
    v_signal = validate_signal(
        symbol=symbol,
        price=price,
        market_type='forex_futures',
        direction=direction,
        rule_code=rule_code,
        snap=snap
    )
    if not v_signal['valid']:
        log_warning(MODULE, f"❌ BLOQUEO DE SEGURIDAD [{symbol}]: Posición abortada. Motivo: {v_signal['reason']}")
        return
    # ====================================

    # Leer config de trading
    try:
        cfg_res = sb.table('trading_config').select('*').eq('id', 1).maybe_single().execute()
        cfg = cfg_res.data or {}
    except:
        cfg = {}

    capital_op_fallback = float(cfg.get('capital_operativo', cfg.get('capital_total', 1000)))
    capital = float(cfg.get('capital_forex_futures', capital_op_fallback))
    
    risk_pct = FOREX_RISK_CONFIG['max_risk_per_trade'] * 100  # 1% default
    try:
        rc_res = sb.table('risk_config').select('max_risk_per_trade_pct').limit(1).execute()
        if rc_res.data:
            risk_pct = float(rc_res.data[0].get('max_risk_per_trade_pct', 2.0))
        else:
            risk_pct = float(cfg.get('max_trade_loss_pct', 1.0))
    except Exception:
        risk_pct = float(cfg.get('max_trade_loss_pct', 1.0))

    # 1. Calcular SL/TP usando Fibonacci
    levels = calculate_forex_sl_tp(
        symbol=symbol,
        direction=direction,
        entry_price=price,
        snap=MARKET_SNAPSHOT_CACHE.get(symbol)
    )
    sl_pips = levels['sl_pips']

    # 2. Calcular lot size basado en riesgo real
    sizing = calculate_forex_lot_size(
        symbol=symbol,
        capital_usd=capital,
        risk_pct=risk_pct,
        sl_pips=sl_pips,
    )

    # Paper trading check
    is_paper = cfg.get('paper_trading', True) is not False

    if is_paper:
        # Paper trading: simular orden
        order = {
            'order_id': int(time.time()),
            'symbol': symbol,
            'side': direction,
            'quantity': sizing['lotes'],
            'price': price,
            'status': 'filled',
        }
        log_info(MODULE, f"[PAPER] Orden Forex: {direction.upper()} {sizing['lotes']} lotes {symbol} @ {price:.5f}")
    else:
        # Live trading: enviar a cTrader
        order = await provider.place_order(
            symbol=symbol,
            side='buy' if direction == 'long' else 'sell',
            order_type='market',
            quantity=sizing['lotes'],
            sl_price=levels['sl_price'],
            tp_price=levels['tp_price'],
        )

    if 'error' in order:
        log_error(MODULE, f"Error abriendo posicion: {order['error']}")
        return

    # 3. Calcular SLV y Hard Stop inicial
    from app.strategy.virtual_sl_recovery import calculate_slv, calculate_hard_stop_pips
    slv_data = calculate_slv(
        entry_price = price,
        side        = direction,
        symbol      = symbol,
        snap        = MARKET_SNAPSHOT_CACHE.get(symbol, {}),
        market_type = 'forex_futures'
    )
    slv_price = slv_data['slv_price']
    slv_hs_pips = calculate_hard_stop_pips(symbol, 'forex_futures', MARKET_SNAPSHOT_CACHE.get(symbol, {}))

    # Registrar en Supabase
    try:
        sb.table('forex_positions').insert({
            'symbol':           symbol,
            'side':             direction,
            'entry_price':      price,
            'lots':             sizing['lotes'],
            'sl_price':         levels['sl_price'],
            'slv_price':        slv_price,
            'slv_hard_stop_pips': slv_hs_pips,
            'tp_price':         levels['tp_price'],
            'rule_code':        rule_code,
            'status':           'open',
            'mode':             'paper' if is_paper else 'live',
            'market_type':      'forex_futures',
            'ctrader_order_id': order.get('order_id'),
            'opened_at':        datetime.now(timezone.utc).isoformat(),
        }).execute()
    except Exception as e:
        log_error(MODULE, f"Error registrando posicion en DB: {e}")

    # Registrar en BOT_STATE
    pos_id = order.get('order_id', f'FX-{int(time.time())}')
    BOT_STATE.positions[pos_id] = {
        'id': pos_id,
        'symbol': symbol,
        'side': direction,
        'avg_entry_price': price,
        'size': sizing['lotes'],
        'sl_price': levels['sl_price'],
        'slv_price': slv_price,
        'slv_hard_stop_pips': slv_hs_pips,
        'tp_price': levels['tp_price'],
        'rule_code': rule_code,
        'status': 'open',
        'market_type': 'forex_futures',
    }
    sm.on_position_opened(symbol, direction, BOT_STATE.positions[pos_id])

    # Telegram
    side_emoji = 'LONG' if direction == 'long' else 'SHORT'
    pip_size = PIP_SIZES.get(symbol, 0.0001)
    sl_pips = abs(price - levels['sl_price']) / pip_size
    tp_pips = abs(levels['tp_price'] - price) / pip_size
    rr_ratio = tp_pips / sl_pips if sl_pips > 0 else 0
    
    await send_telegram_message(
        f"FOREX {side_emoji} [{symbol}]\n"
        f"Regla: {rule_code} | Score: {signal.get('score', 0):.2f}\n"
        f"Entrada: {price:.5f}\n"
        f"SL: {levels['sl_price']:.5f} (-{sl_pips:.0f} pips)\n"
        f"TP: {levels['tp_price']:.5f} (+{tp_pips:.0f} pips) RR 1:{rr_ratio:.1f}\n"
        f"Lotes: {sizing['lotes']} | Riesgo: ${sizing['risk_usd']:.2f}"
    )


# ══════════════════════════════════════════════════
#  CYCLE 5m — Position Management (Forex)
# ══════════════════════════════════════════════════

async def _forex_process_symbol_5m(symbol: str, provider: CTraderProtobufProvider, sb):
    """Procesar un simbolo Forex en ciclo 5m."""
    try:
        # 1. Obtener precio actual
        current_price = await provider.get_current_price(symbol)
        if current_price <= 0:
            return

        # 2. Actualizar velas en memoria
        update_current_candle_close(symbol=symbol, current_price=current_price)

        # 3. Snapshot cache update
        MARKET_SNAPSHOT_CACHE[symbol] = MARKET_SNAPSHOT_CACHE.get(symbol, {})
        MARKET_SNAPSHOT_CACHE[symbol]['price'] = current_price

        # --- VERIFICAR EJECUCIÓN LIMIT ORDERS (SWING) ---
        try:
            from app.strategy.swing_orders import check_limit_order_execution
            await check_limit_order_execution(symbol=symbol, current_price=current_price, provider=provider, sb=sb)
        except Exception as limit_err:
            log_error(MODULE, f"Error verificando ejecución de orden límite swing para {symbol}: {limit_err}")

        # 4. Smart Exit: SAR Phase Change
        snap = MARKET_SNAPSHOT_CACHE.get(symbol, {})
        sar_data = MEMORY_STORE.get(symbol, {}).get('sar', {})
        sar_phase = sar_data.get('phase', 'neutral')
        sar_changed_at = sar_data.get('changed_at')

        positions = BOT_STATE.get_positions_by_symbol(symbol)
        for position in positions:
            # --- SLVM v2 (Recovery & Hard Stop) ---
            from app.strategy.virtual_sl_recovery import process_symbol_5m_with_slvm_v2
            await process_symbol_5m_with_slvm_v2(
                symbol        = symbol,
                current_price = current_price,
                snap          = snap,
                sb            = sb,
                market_type   = 'forex_futures',
                position      = position
            )
            
            # --- MARGIN CALL ALERT (Amenaza al Capital) ---
            entry_p_margin = float(position.get('entry_price') or position.get('avg_entry_price') or 0)
            if entry_p_margin > 0:
                is_long_margin = (position.get('side') or 'long').lower() in ['long', 'buy']
                qty_margin = float(position.get('size') or position.get('lots') or 0)
                # Aproximación USD (En Forex real se debería usar pip_value * pips, pero esto es aproximado)
                # Usaremos la misma lógica básica de pnl_pct y lo proyectamos si es posible, o pnl raw.
                if 'total_pnl_usd' in position:
                    upnl_usd_margin = float(position['total_pnl_usd'] or 0)
                else:
                    # Alternativa simple: usar el %
                    upnl_pct_margin = (current_price - entry_p_margin) / entry_p_margin * 100 if is_long_margin else (entry_p_margin - current_price) / entry_p_margin * 100
                    # Asumimos que margin_call_alert_pct ya lidia con el ratio sobre la cuenta. 
                    # Pero check_margin_call espera pnl_usd. Lo pasamos crudo.
                    from app.core.pnl_calculator import calculate_pnl
                    upnl_usd_margin, _ = calculate_pnl('forex', position.get('side', 'long'), entry_p_margin, current_price, qty_margin, symbol, sb)
                
                from app.core.position_monitor import check_margin_call_alert
                await check_margin_call_alert(
                    symbol  = symbol,
                    pnl_usd = upnl_usd_margin,
                    sb      = sb,
                    pos_id  = str(position.get('id', ''))
                )



            # 4. Smart Exit: SAR Phase Change
            if sar_changed_at:
                side = (position.get('side') or '').lower()
                if (sar_phase == 'short' and side == 'long') or \
                   (sar_phase == 'long' and side == 'short'):

                    await _execute_paper_close(position, current_price, 'sar_phase_change_fx', sb)
                    entry = float(position.get('avg_entry_price', 0))
                    if entry > 0:
                        if side == 'long':
                            pnl_pips = (current_price - entry) / PIP_SIZES.get(symbol, 0.0001)
                        else:
                            pnl_pips = (entry - current_price) / PIP_SIZES.get(symbol, 0.0001)
                    else:
                        pnl_pips = 0

                    await send_telegram_message(
                        f"FOREX SAR REVERSAL [{symbol}]\n"
                        f"SAR 4h -> {sar_phase.upper()}\n"
                        f"Cerrando {side.upper()}: {pnl_pips:+.1f} pips\n"
                        f"Precio: {current_price:.5f}"
                    )
                    continue # Sigue con la siguiente posicion

            # 5. Smart Exit: Signal Reversal
            current_mtf = float(snap.get('mtf_score', 0))
            trading_config = BOT_STATE.config_cache

            reversal = await check_signal_reversal(
                position=position,
                current_mtf=current_mtf,
                current_price=current_price,
                config=trading_config,
                snap=snap
            )

            if reversal.get('should_exit'):
                await _execute_paper_close(position, current_price, 'signal_reversal_fx', sb)
                await send_telegram_message(
                    f"FOREX SALIDA INTELIGENTE [{symbol}]\n"
                    f"MTF giro: {current_mtf:.4f}\n"
                    f"PnL: {reversal.get('pnl_pct', 0):+.2f}%"
                )
                continue

            # 6. SL/TP check (manual for Forex since paper mode)
            sl = float(position.get('sl_price', 0))
            tp = float(position.get('tp_price', position.get('tp_partial_price', 0)))
            side = (position.get('side') or '').lower()

            if sl > 0:
                if (side == 'long' and current_price <= sl) or \
                   (side == 'short' and current_price >= sl):
                    await _execute_paper_close(position, current_price, 'sl_hit_fx', sb)
                    await send_telegram_message(
                        f"FOREX SL HIT [{symbol}]\n"
                        f"Precio: {current_price:.5f}\n"
                        f"SL: {sl:.5f}"
                    )
                    continue

            if tp > 0:
                if (side == 'long' and current_price >= tp) or \
                   (side == 'short' and current_price <= tp):
                    await _execute_paper_close(position, current_price, 'tp_hit_fx', sb)
                    await send_telegram_message(
                        f"FOREX TP HIT [{symbol}]\n"
                        f"Precio: {current_price:.5f}\n"
                        f"TP: {tp:.5f}"
                    )
                    continue

        # 7. Heartbeat
        try:
            sb.table('bot_state').upsert({
                'symbol': symbol,
                'last_5m_cycle_at': datetime.now(timezone.utc).isoformat(),
                'last_updated': datetime.now(timezone.utc).isoformat(),
            }, on_conflict='symbol').execute()
        except:
            pass

    except Exception as e:
        log_error(MODULE, f"5m cycle error {symbol}: {e}")


async def forex_cycle_5m():
    """Ciclo 5m Forex: Gestion de posiciones y smart exits."""
    global _forex_provider
    log_debug(MODULE, "--- Forex 5m Cycle ---")

    sb = get_supabase()
    symbols = FOREX_SYMBOLS

    provider = _forex_provider
    if not provider or not provider._connected:
        log_warning(MODULE, "Provider Forex desconectado. Intentando reconectar en segundo plano y omitiendo ciclo 5m.")
        asyncio.create_task(get_forex_provider())
        return

    try:
        tasks = [_forex_process_symbol_5m(s, provider, sb) for s in symbols]
        await asyncio.gather(*tasks, return_exceptions=True)

        # ── TICK STATE MACHINE (Waiting/Ambiguous) ──
        for sym in symbols:
            sm.tick_waiting(sym)
            sm.tick_ambiguous(sym)

        # ── SYNC BROKER BALANCE TO SUPABASE ──
        try:
            balance_info = await provider.get_account_balance()
            if balance_info and 'balance' in balance_info:
                current_params = sb.table('trading_config').select('regime_params').eq('id', 1).maybe_single().execute()
                params = (current_params.data or {}).get('regime_params') or {}
                params['broker_balance_forex'] = balance_info['balance']
                sb.table('trading_config').update({'regime_params': params}).eq('id', 1).execute()
                log_debug(MODULE, f"Broker balance synced: ${balance_info['balance']:.2f}")
        except Exception as bal_err:
            log_debug(MODULE, f"Balance sync skip: {bal_err}")

    except Exception as e:
        log_error(MODULE, f"Error global forex 5m: {e}")


# ══════════════════════════════════════════════════
#  CYCLE 15m — Full Analysis (Forex)
# ══════════════════════════════════════════════════

from app.strategy.profit_capture import evaluate_profit_capture
from app.strategy.profit_ladder import evaluate_profit_ladder, check_basis_crossed
from app.core.position_monitor import _execute_paper_close

async def process_forex_profit_management_15m(
    symbol: str,
    position: dict,
    current_price: float,
    snap: dict,
    df_15m: pd.DataFrame,
    sb,
    provider
) -> bool:
    """
    Gestión de ganancias en ciclo 15m para Forex.
    Corre MÓDULO A (Profit Capture) y MÓDULO B (Profit Ladder).
    """
    side = str(position.get('side', 'long'))
    pos_id = position.get('id')
    market_type = 'forex_futures'

    # ── MÓDULO A: Profit Capture ───────────────
    result_a = evaluate_profit_capture(
        symbol, side, position, current_price,
        snap, df_15m, market_type
    )

    if result_a['action'] in ('close', 'flip'):
        log_info('PROFIT_FX', f'💰 PROFIT CAPTURE [{symbol}]: {result_a["reason"]}')
        
        await _execute_paper_close(
            position, current_price,
            f'profit_capture_fx_{"_".join(result_a["triggered_by"])}',
            sb
        )

        if result_a['action'] == 'flip' and result_a.get('flip_direction'):
            flip_dir = result_a['flip_direction']
            log_info('PROFIT_FX', f'🔄 FLIP [{symbol}]: {side} → {flip_dir.upper()}')
            
            signal_flip = {
                'direction': flip_dir,
                'rule_code': 'profit_flip_fx',
                'score': 1.0
            }
            await open_forex_position(
                symbol=symbol, signal=signal_flip,
                price=current_price, provider=provider, sb=sb
            )

        await send_telegram_message(
            f'{"🔄 FLIP" if result_a["action"]=="flip" else "💰 PROFIT CAPTURE"} [{symbol}]\n'
            f'{result_a["conditions_met"]}/3 condiciones\n'
            f'Señales: {", ".join(result_a["triggered_by"])}\n'
            f'PnL: +{result_a["pnl_pct"]:.2f}%'
        )
        return True

    # ── Actualizar cruce de BASIS ─────────────
    basis_check = check_basis_crossed(position, current_price, snap, df_15m)
    if basis_check['crossed'] and not position.get('basis_crossed'):
        from app.strategy.virtual_sl_recovery import get_db_key_and_record_id
        db_key_name, db_record_id = get_db_key_and_record_id(position, 'forex_positions')
        try:
            sb.table('forex_positions').update({
                'basis_crossed': True,
                'basis_crossed_at': datetime.now(timezone.utc).isoformat(),
            }).eq(db_key_name, db_record_id).execute()
        except Exception as e:
            from app.core.logger import log_error
            log_error('PROFIT_FX', f"Error updating basis_crossed: {e}")
            
        position['basis_crossed'] = True
        log_info('PROFIT_FX', f'📊 BASIS CRUZADO [{symbol}]: {basis_check["reason"]}')

    # ── MÓDULO B: Profit Ladder ────────────────
    result_b = evaluate_profit_ladder(
        symbol, side, position, current_price,
        snap, df_15m, market_type
    )

    if result_b['action'] == 'close':
        log_info('PROFIT_FX', f'📉 PROFIT LADDER CLOSE [{symbol}]: {result_b["reason"]}')
        await _execute_paper_close(
            position, current_price,
            f'profit_ladder_fx_{result_b.get("triggered_by", "ema")}',
            sb
        )
        await send_telegram_message(
            f'📉 PROFIT LADDER [{symbol}]\n'
            f'{result_b["reason"]}\n'
            f'Banda: {result_b.get("current_band")}'
        )
        return True

    elif result_b['action'] == 'update_floor':
        from app.strategy.virtual_sl_recovery import get_db_key_and_record_id
        db_key_name, db_record_id = get_db_key_and_record_id(position, 'forex_positions')
        try:
            sb.table('forex_positions').update({
                'profit_floor_band': result_b['new_floor_band'],
                'profit_floor_price': result_b['new_floor_price'],
                'highest_band_reached': result_b['current_band'],
            }).eq(db_key_name, db_record_id).execute()
        except Exception as e:
            from app.core.logger import log_error
            log_error('PROFIT_FX', f"Error updating profit floor: {e}")
            
        log_info('PROFIT_FX', f'⬆️ FLOOR ACTUALIZADO [{symbol}]: {result_b["reason"]}')
        position['profit_floor_band'] = result_b['new_floor_band']
        position['profit_floor_price'] = result_b['new_floor_price']
        position['highest_band_reached'] = result_b['current_band']

    return False

async def _forex_process_symbol_15m(symbol: str, provider: CTraderProtobufProvider, sb):
    """Procesamiento completo 15m para un simbolo Forex."""
    global _forex_cycle_count
    t0 = time.time()

    try:
        # PHASE 1: Download OHLCV (Smart Frequency)
        cycle_count = _forex_cycle_count
        DOWNLOAD_FREQUENCY = {
            '5m':  1,
            '15m': 1,
            '30m': 2,
            '1h':  4,
            '4h':  16,
            '1d':  96,
        }

        timeframes_to_fetch = [
            tf for tf, freq in DOWNLOAD_FREQUENCY.items()
            if cycle_count % freq == 0 or get_memory_df(symbol, tf) is None
        ]

        # Descargas paralelas
        if timeframes_to_fetch:
            for tf in timeframes_to_fetch:
                limit = 300 if tf in ['5m', '15m', '30m', '1h'] else 500
                try:
                    res = await provider.get_ohlcv(symbol, tf, limit=limit)
                    if res is not None and not res.empty:
                        loop = asyncio.get_running_loop()
                        df_tf = await loop.run_in_executor(None, calculate_all_indicators, res, BOT_STATE.config_cache)
                        update_memory_df(symbol, tf, df_tf)
                        await upsert_forex_candles(symbol, tf, df_tf, sb)
                except Exception as res_err:
                    log_warning(MODULE, f"Error descargando {tf} para {symbol}: {res_err}")
                    if tf == '15m':
                        raise res_err
                # Pequeña pausa para evitar rate limit de cTrader
                await asyncio.sleep(0.4)

        # Recuperar DF 15m
        df = get_memory_df(symbol, '15m')
        if df is None or df.empty:
            log_warning(MODULE, f"No hay datos 15m para {symbol}")
            return

        last_row = df.iloc[-1]
        current_price = float(last_row['close'])

        # Guardar ATR en metadata
        if 'metadata' not in MEMORY_STORE.get(symbol, {}):
            MEMORY_STORE[symbol]['metadata'] = {}
        MEMORY_STORE[symbol]['metadata']['current_atr'] = float(last_row.get('atr', 0))

        # PHASE 2: Spike + MTF
        vol_sma = df['volume'].rolling(20).mean().iloc[-1]
        spike_result = {'detected': False, 'ratio': 0, 'direction': ''}
        try:
            spike_info = detect_spike(df, {'volume_sma_20': vol_sma, 'symbol': symbol, 'zone': 0}, BOT_STATE.config_cache, cycle_id=None)
            if spike_info:
                spike_result = {
                    'detected': True,
                    'ratio': spike_info.get('spike_ratio', 0),
                    'direction': spike_info.get('direction', ''),
                }
        except:
            pass

        # MTF score
        all_inds = {}
        for tf in ['15m', '30m', '1h', '4h', '1d']:
            m_df = get_memory_df(symbol, tf)
            if m_df is not None and not m_df.empty:
                last_tf = m_df.iloc[-1]
                all_inds[tf] = {
                    'ema_3': float(last_tf.get('ema1', 0)),
                    'ema_9': float(last_tf.get('ema2', 0)),
                    'ema_20': float(last_tf.get('ema3', 0)),
                    'ema_50': float(last_tf.get('ema4', 0)),
                    'rsi_14': float(last_tf.get('rsi', 50)),
                    'macd_histogram': float(last_tf.get('macd', 0)),
                    'close': float(last_tf.get('close', 0)),
                }

        mtf_result = calculate_mtf_score(symbol, all_inds, spike_direction=spike_result['direction'] or 'BULLISH')
        cur_mtf_score = mtf_result.get('score', 0.0)

        # PHASE 3: Regime
        regime = classify_market_risk(df)
        await update_regime_if_changed(symbol, regime, sb)

        # PHASE 4: Snapshot
        await write_forex_snapshot(symbol, df, regime, spike_result, cur_mtf_score, sb)

        # ── INTEGRACIÓN MÓDULO A Y B (Gestión de Ganancias) ──
        positions = BOT_STATE.get_positions_by_symbol(symbol)
        snap_for_profit = MARKET_SNAPSHOT_CACHE.get(symbol, {})
        for position in list(positions):
            closed = await process_forex_profit_management_15m(
                symbol=symbol,
                position=position,
                current_price=current_price,
                snap=snap_for_profit,
                df_15m=df,
                sb=sb,
                provider=provider
            )
            if closed:
                pass # Already closed

        # PHASE 5: Strategy Engine Evaluation
        engine = StrategyEngine.get_instance()
        if not engine.loaded:
            await engine.load()

        snap = MARKET_SNAPSHOT_CACHE.get(symbol, {}).copy()
        snap.update({
            'price': current_price,
            'adx': float(last_row.get('adx', 25)),
            'mtf_score': cur_mtf_score,
            'pinescript_signal': str(last_row.get('last_pinescript_signal', '') or ''),
            'regime': regime['category'],
        })
        MARKET_SNAPSHOT_CACHE[symbol] = snap

        df_4h = get_memory_df(symbol, '4h')
        df_5m = get_memory_df(symbol, '5m')
        context = engine.build_context(snap=snap, df_15m=df, df_4h=df_4h, df_5m=df_5m)

        # ── STATE MACHINE & AMBIGUITY CHECK ──
        from app.core.symbol_state import detect_market_ambiguity
        snap_for_sm = snap.copy()
        snap_for_sm.update({'sar_trend_4h': int(last_row.get('sar_trend_4h',0)), 'sar_trend_15m': int(last_row.get('sar_trend_15m',0)), 'fibonacci_zone': int(last_row.get('fib_zone', 0))})
        ambiguity = detect_market_ambiguity(snap_for_sm)
        
        if ambiguity['is_ambiguous']:
            log_info('AMBIGUOUS_FX', f"{symbol}: {ambiguity['reason']}")
            sm.set_ambiguous(symbol, ambiguity['reason'])
        else:
            signal = engine.get_best_signal(context=context, strategy_type='scalping', cycle='15m')
            
            # --- FASE 5.5: V1 Engine Fallback (Crypto Logic para Aa23, Bb23, etc) ---
            if not signal:
                from app.strategy.rule_engine import evaluate_all_rules, load_rules_to_memory
                from app.analysis.fibonacci_bb import extract_fib_levels
                
                # Fetch V1 rules from supabase 
                # (We can use a cached version ideally, but load_rules_to_memory caches internally if we pass it)
                all_v1_rules = await load_rules_to_memory(sb)
                fib_levels = extract_fib_levels(df)
                
                # --- INJECT 5M DATA FOR Aa13 ---
                ema3_5m = 0
                ema9_5m = 0
                ema20_5m = 0
                bb_upper_5m_opens = False
                bb_lower_5m_opens = False
                
                if df_5m is not None and len(df_5m) >= 2:
                    c0 = df_5m.iloc[-1]
                    c1 = df_5m.iloc[-2]
                    ema3_5m = c0.get('ema1', c0.get('ema_3', 0))
                    ema9_5m = c0.get('ema2', c0.get('ema_9', 0))
                    ema20_5m = c0.get('ema3', c0.get('ema_20', 0))
                    
                    u0 = float(c0.get('upper_2', 0))
                    u1 = float(c1.get('upper_2', 0))
                    if u0 > 0 and u1 > 0: bb_upper_5m_opens = (u0 > u1)
                    
                    l0 = float(c0.get('lower_2', 0))
                    l1 = float(c1.get('lower_2', 0))
                    if l0 > 0 and l1 > 0: bb_lower_5m_opens = (l0 < l1)
                
                df.loc[df.index[-1], 'ema3_5m'] = ema3_5m
                df.loc[df.index[-1], 'ema9_5m'] = ema9_5m
                df.loc[df.index[-1], 'ema20_5m'] = ema20_5m
                df.loc[df.index[-1], 'bb_upper_5m_opens'] = bb_upper_5m_opens
                df.loc[df.index[-1], 'bb_lower_5m_opens'] = bb_lower_5m_opens
                # -------------------------
                
                # We evaluate V1 engine for Long
                v1_long = evaluate_all_rules(df, fib_levels, regime, pinescript_signal=str(last_row.get('last_pinescript_signal', '') or ''), cfg=BOT_STATE.config_cache, direction='long', rules=all_v1_rules, source_tf='15m', market_type='forex_futures')
                v1_short = evaluate_all_rules(df, fib_levels, regime, pinescript_signal=str(last_row.get('last_pinescript_signal', '') or ''), cfg=BOT_STATE.config_cache, direction='short', rules=all_v1_rules, source_tf='15m', market_type='forex_futures')
                
                if v1_long:
                    signal = {'rule_code': v1_long, 'direction': 'long', 'strategy_type': 'scalping', 'cycle': '15m'}
                elif v1_short:
                    signal = {'rule_code': v1_short, 'direction': 'short', 'strategy_type': 'scalping', 'cycle': '15m'}

            if signal:
                await engine.log_evaluation(symbol, signal, context)

                max_global = int(BOT_STATE.config_cache.get('max_open_trades', 16))
                current_open = len(BOT_STATE.positions)
                max_per_pair = int(BOT_STATE.config_cache.get('max_positions_per_symbol', 4))

                if current_open >= max_global:
                    log_info('POSITION_LIMIT_FX', f'{symbol}: Limite GLOBAL {max_global} alcanzado')
                else:
                    sm_check = sm.can_open(symbol, signal['direction'], current_price, max_per_pair)
                    
                    if not sm_check['allowed']:
                        log_info('STATE_MACHINE_FX', f"{symbol}: Bloqueado - {sm_check['reason']}")
                    else:
                        if sm_check.get('is_flip'):
                            log_info('FLIP_FX', f"{symbol}: FLIP {signal['direction']} - Evaluando posiciones opuestas")
                            existing_positions = BOT_STATE.get_positions_by_symbol(symbol)
                            for p in existing_positions:
                                if p.get('side', '').lower() != signal['direction'].lower():
                                    entry = float(p.get('avg_entry_price') or p.get('entry_price') or current_price)
                                    pnl_pct = 0.0
                                    if entry > 0:
                                        if p.get('side', '').lower() in ('long', 'buy'):
                                            pnl_pct = (current_price - entry) / entry * 100
                                        else:
                                            pnl_pct = (entry - current_price) / entry * 100
                                            
                                    if pnl_pct < -1.0:
                                        log_info('FLIP_FX', f"[{symbol}] Flip abortado para esta posición: PNL {pnl_pct:.2f}% < -1.0%. Se retiene para EREP.")
                                        continue

                                    try:
                                        from app.core.position_monitor import _execute_paper_close
                                        await _execute_paper_close(p, current_price, f"flip_{signal['direction']}_fx", sb)
                                        sm.on_position_closed(symbol, f"flip_{signal['direction']}_fx", all_closed=True)
                                    except Exception as e:
                                        log_error(MODULE, f"Error en flip close para {symbol}: {e}")
                                        
                        # ── MEJORA C: Filtro Correlación USD ──
                        all_forex_pos = [p for p in BOT_STATE.positions.values() if p.get('market_type') == 'forex']
                        usd_check = check_usd_exposure_filter(symbol, signal['direction'], all_forex_pos)
                        if not usd_check['passed']:
                            log_info('USD_CORR_FX', f"{symbol}: {usd_check['reason']}")
                        else:
                            # Proceder a abrir
                            await open_forex_position(
                                symbol=symbol,
                                signal=signal,
                                price=current_price,
                                provider=provider,
                                sb=sb,
                            )
            else:
                # Log near-misses
                all_results = (
                    engine.evaluate_all(context, 'long', 'scalping', '15m') +
                    engine.evaluate_all(context, 'short', 'scalping', '15m')
                )
                for r in all_results:
                    if r['score'] >= 0.40:
                        await engine.log_evaluation(symbol, r, context)

        # --- ESTRATEGIA CUSTOM APEX_EMA (SwingEma) para Forex ---
        try:
            from app.strategy.swing_orders import process_swing_ema_strategy
            await process_swing_ema_strategy(
                symbol=symbol,
                df_15m=df,
                snap=snap,
                sb=sb
            )
        except Exception as swing_ema_err:
            log_error(MODULE, f"{symbol}/15m swing ema error: {swing_ema_err}")

        # PHASE 6: Swing Orders (4h cycle = cada 16 ciclos)
        if _forex_cycle_count % 16 == 0:
            try:
                from app.strategy.swing_orders import process_swing_orders
                df_4h_safe = get_memory_df(symbol, '4h')
                if df_4h_safe is not None and not df_4h_safe.empty:
                    await process_swing_orders(
                        symbol=symbol,
                        timeframe='4h',
                        df=df_4h_safe,
                        snap=snap,
                        sb=sb,
                    )

                    # Scalping 4h (Aa31/Bb31)
                    existing_positions_4h = BOT_STATE.get_positions_by_symbol(symbol)
                    max_per_pair = int(BOT_STATE.config_cache.get('max_positions_per_symbol', 4))
                    
                    if len(existing_positions_4h) < max_per_pair:
                        context_4h = engine.build_context(snap=snap, df_15m=df, df_4h=df_4h_safe)
                        signal_4h = engine.get_best_signal(context=context_4h, strategy_type='scalping', cycle='4h')
                        if signal_4h:
                            # ── PRICE IMPROVEMENT CHECK (DCA) ──
                            can_open = True
                            if existing_positions_4h:
                                last_pos = sorted(existing_positions_4h, key=lambda x: x.get('opened_at', ''), reverse=True)[0]
                                last_entry = float(last_pos.get('entry_price') or last_pos.get('avg_entry_price') or 0)
                                direction = signal_4h['direction']
                                
                                if direction == "long" and current_price >= last_entry:
                                    log_info('DCA_BLOCK_FX_4H', f'{symbol}: No mejora precio LONG ({current_price} >= {last_entry})')
                                    can_open = False
                                elif direction == "short" and current_price <= last_entry:
                                    log_info('DCA_BLOCK_FX_4H', f'{symbol}: No mejora precio SHORT ({current_price} <= {last_entry})')
                                    can_open = False
                            
                            if can_open:
                                # ── MEJORA C: Filtro Correlación USD (4h) ──
                                all_forex_pos_4h = [p for p in BOT_STATE.positions.values() if p.get('market_type') == 'forex']
                                usd_check_4h = check_usd_exposure_filter(symbol, signal_4h['direction'], all_forex_pos_4h)
                                if not usd_check_4h['passed']:
                                    log_info('USD_CORR_FX_4H', f"{symbol}: {usd_check_4h['reason']}")
                                else:
                                    await open_forex_position(
                                        symbol=symbol,
                                        signal=signal_4h,
                                        price=current_price,
                                        provider=provider,
                                        sb=sb,
                                    )
            except Exception as swing_e:
                log_error(MODULE, f'{symbol}/4h swing error: {swing_e}')

        elapsed = time.time() - t0
        log_info(MODULE, f'{symbol}/15m: ciclo completado ({elapsed:.1f}s)')

    except Exception as e:
        import traceback
        log_error(MODULE, f"Error {symbol}/15m: {e}\n{traceback.format_exc()}")


async def forex_cycle_15m():
    """Ciclo 15m Forex: Analisis completo + senales."""
    global _forex_provider, _forex_cycle_count
    _forex_cycle_count += 1

    log_info(MODULE, f"--- Forex 15m Cycle #{_forex_cycle_count} ---")

    sb = get_supabase()
    symbols = FOREX_SYMBOLS

    provider = _forex_provider
    if not provider or not provider._connected:
        log_warning(MODULE, "Provider Forex desconectado. Intentando reconectar en segundo plano y omitiendo ciclo 15m.")
        asyncio.create_task(get_forex_provider())
        return

    try:
        # Sync config
        try:
            res = sb.table('trading_config').select('*').eq('id', 1).maybe_single().execute()
            if res.data:
                BOT_STATE.config_cache.update(res.data)
        except:
            pass

        # Procesar todos los simbolos en paralelo
        tasks = [_forex_process_symbol_15m(s, provider, sb) for s in symbols]
        await asyncio.gather(*tasks, return_exceptions=True)

        # Performance alerts
        try:
            await check_performance_alerts()
        except Exception as e:
            log_error(MODULE, f"Performance alerts error: {e}")

    except Exception as e:
        log_error(MODULE, f"Error global forex 15m: {e}")


# ══════════════════════════════════════════════════
#  INIT & MAIN
# ══════════════════════════════════════════════════

async def get_forex_provider():
    """
    Singleton del provider Forex.
    La conexión TCP se mantiene abierta.
    """
    global _forex_provider
    if _forex_provider is None or \
       not _forex_provider._authenticated:
        _forex_provider = create_provider(
            'forex_futures'
        )
        connected = await _forex_provider.connect()
        if not connected:
            raise Exception(
                'No se pudo conectar a cTrader'
            )
        # Subscribir a precios en tiempo real
        await _forex_provider.subscribe_prices(
            symbols  = FOREX_SYMBOLS,
            callback = _handle_forex_price
        )
        log_info('FOREX',
            f'Provider Protobuf inicializado: '
            f'{FOREX_SYMBOLS}'
        )
    return _forex_provider


def _handle_forex_price(symbol, mid, bid, ask):
    """
    Callback de precio en tiempo real.
    Actualiza MEMORY_STORE con el precio actual.
    Equivalente al WebSocket de Binance.
    """
    if symbol not in MEMORY_STORE:
        MEMORY_STORE[symbol] = {}
    MEMORY_STORE[symbol]['current_price'] = mid
    MEMORY_STORE[symbol]['bid']           = bid
    MEMORY_STORE[symbol]['ask']           = ask
    MEMORY_STORE[symbol]['last_tick']     = \
        datetime.now(timezone.utc)


async def init_forex_worker(supabase) -> Optional[CTraderProtobufProvider]:
    """
    Inicializar el worker de Forex con
    provider Protobuf.
    """
    try:
        provider = await get_forex_provider()
    except Exception as e:
        log_error(MODULE, f"Error inicializando provider Protobuf: {e}")
        return None

    log_info('FOREX_SCHEDULER',
        'Precalentando velas históricas...'
    )

    # Descargar historial para todos los símbolos
    for symbol in FOREX_SYMBOLS:
        MEMORY_STORE[symbol] = \
            MEMORY_STORE.get(symbol, {})

        for tf in ['5m','15m','30m','1h','4h','1d']:
            try:
                df = await provider.get_ohlcv(
                    symbol, tf, limit=300
                )
                if df is not None and \
                   not df.empty:
                    loop = asyncio.get_running_loop()
                    df = await loop.run_in_executor(None, calculate_all_indicators, df, BOT_STATE.config_cache)
                    df = calculate_parabolic_sar(df)

                    MEMORY_STORE[symbol][tf] = {
                        'df': df
                    }
                    log_info('FOREX',
                        f'{symbol}/{tf}: '
                        f'{len(df)} velas OK'
                    )
            except Exception as e:
                log_error('FOREX',
                    f'{symbol}/{tf}: {e}'
                )

    log_info('FOREX_SCHEDULER',
        '✅ Forex Protobuf Worker listo'
    )
    
    # Cargar Strategy Engine
    engine = StrategyEngine.get_instance(supabase)
    if not engine.loaded:
        await engine.load()
    log_info(MODULE, "Strategy Engine v1.0 cargado para Forex")

    return provider


async def main():
    """
    Entry point del Forex Scheduler.
    Ejecuta ciclos de 5m y 15m via APScheduler.
    """
    log_info(MODULE, "=== FOREX SCHEDULER STARTING ===")

    sb = get_supabase()
    provider = await init_forex_worker(sb)

    if not provider:
        log_error(MODULE, "ABORT: No se pudo inicializar el worker Forex.")
        return

    # Scheduler
    scheduler = AsyncIOScheduler()

    # 5m cycle: offset 20s para no colisionar con Crypto (que usa 10s)
    scheduler.add_job(
        forex_cycle_5m,
        CronTrigger(minute='*/5', second='20'),
        id='forex_5m',
        replace_existing=True,
    )

    # 15m cycle: offset 45s (Crypto usa 30s)
    scheduler.add_job(
        forex_cycle_15m,
        CronTrigger(minute='*/15', second='45'),
        id='forex_15m',
        replace_existing=True,
    )

    log_info(MODULE, "Scheduler Forex configurado. Ejecutando ciclo inicial...")

    # Correr ciclos iniciales
    asyncio.create_task(forex_cycle_15m())
    asyncio.create_task(forex_cycle_5m())

    scheduler.start()

    # Keep alive
    try:
        while True:
            await asyncio.sleep(3600)
    except (KeyboardInterrupt, SystemExit):
        log_info(MODULE, "Forex scheduler detenido.")
    finally:
        if _forex_provider:
            await _forex_provider.disconnect()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        log_info(MODULE, "Forex scheduler detenido manualmente.")
